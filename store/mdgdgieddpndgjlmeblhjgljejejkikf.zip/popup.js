let donateButton = document.querySelector('#donate');
let githubButton = document.querySelector('#github-button');
let globalURL;
let currentSettings;

donateButton.onclick = function() {
	window.open("https://www.paypal.com/donate?hosted_button_id=MD9WRXSTLB49W");
};

githubButton.onclick = function() {
	window.open("https://github.com/omnidevZero/YouTubeRedux");
};

let settingsElements = document.querySelectorAll('.settings:not(.slider-control)');
for (let i = 0; i < settingsElements.length; i++) {
	settingsElements[i].addEventListener('change', function() {
		if (this.parentElement.nextElementSibling != null && this.parentElement.nextElementSibling.classList.contains('subsettings-container')) {
			let subsettings = this.parentElement.nextElementSibling.querySelectorAll('.subsetting input[type="checkbox"]');
			if (this.checked) {
				subsettings.forEach(element => {
					element.removeAttribute('disabled');
				});
			} else {
				subsettings.forEach(element => {
					element.setAttribute('disabled', '');
					element.checked = false;
				});
			}
		}
		saveSettings();
	});
}

document.querySelector('input[type="range"]').addEventListener('change', function() {
	let inputControl = document.querySelector('.slider-control');
	inputControl.value = this.value;
	saveSettings();
	changeGridWidth(this.value);
});

document.querySelector('.slider-control').addEventListener('change', function() {
	let slider = document.querySelector('input[type="range"]');
	slider.value = this.value;
	saveSettings();
	changeGridWidth(this.value);
});

//navigation buttons
document.querySelector('#right-arrow').addEventListener('click', function() {
	if (this.hasAttribute('disabled')) {
		return;
	}

	document.querySelector('#left-arrow').removeAttribute('disabled');
	let currentActivePage = document.querySelector('#all-pages').getAttribute("active-page");
	document.querySelector('#all-pages').setAttribute("active-page", ++currentActivePage);
	document.querySelector('#all-pages').style = `transform: translateX(-${(currentActivePage - 1)*100}%)`;

	if (currentActivePage >= 3) {
		document.querySelector('#right-arrow').setAttribute('disabled', '');
		if (!currentSettings.completedSettingsTutorial) {
			document.querySelector("input[name='completedSettingsTutorial']").checked = true;
			this.classList.remove("glow");
			saveSettings();
		}
	}
});

document.querySelector('#left-arrow').addEventListener('click', function() {
	if (this.hasAttribute('disabled')) {
		return;
	}

	document.querySelector('#right-arrow').removeAttribute('disabled');
	let currentActivePage = document.querySelector('#all-pages').getAttribute("active-page");
	document.querySelector('#all-pages').setAttribute("active-page", --currentActivePage);
	document.querySelector('#all-pages').style = `transform: translateX(-${(currentActivePage - 1)*100}%)`;

	if (currentActivePage <= 1) {
		document.querySelector('#left-arrow').setAttribute('disabled', '');
	}
});

//font selection
document.querySelector('select[name="titleFontValue"]').addEventListener('change', function() {
	if (this.querySelector('option:last-child').selected) {
		let fontChoice = prompt('Enter your custom font name.\nTo reset it change to another value and then back to custom.', '\'Times New Roman\'');
		if (fontChoice != null) {
			this.querySelector('option:last-child').value = fontChoice;
			saveSettings();
		}
	}
});

//custom small player size
document.querySelector('select[name="smallPlayerWidth"]').addEventListener('change', function() {
	if (this.querySelector('option:last-child').selected) {
		let sizeChoice = prompt('Enter your custom player height in pixels (width will be automatically adjusted).\nTo reset it change to another value and then back to custom.', '900');
		if (sizeChoice != null) {
			this.querySelector('option:last-child').value = sizeChoice;
			saveSettings();
		}
	}
});

//logo preview
document.querySelectorAll('label.logo-label').forEach(element => {
	element.addEventListener('mouseenter', function() {
		let preview = document.querySelector('.logo-preview');
		let previewImg = preview.querySelector('img');
		let previewExtension = this.firstChild.value == 'XL' ? 'png' : 'svg';
		previewImg.src = `/images/${this.firstChild.value}logo.${previewExtension}`;
		preview.style.display = 'flex';
	});
});
document.querySelectorAll('label.logo-label').forEach(element => {
	element.addEventListener('mouseleave', function() {
		let preview = document.querySelector('.logo-preview');
		preview.style.display = 'none';
	});
});

//reset
document.querySelector('#restore-defaults').addEventListener('click', () => {
	const confirmation = confirm('All settings will be reset to default values and current page will be refreshed. Continue?');
	if (confirmation) {
		chrome.storage.sync.clear();
		chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
			chrome.tabs.reload(tabs[0].id);
		});
		window.close();
	}
});

//export/import config
document.querySelector('#export-config').addEventListener('click', () => {
	chrome.tabs.create({
		url: `./config.html?data=${btoa(JSON.stringify(currentSettings, null, 2))}`
	});
});

function saveSettings() {
	let newSettings = {};
	//save slider
	newSettings[document.querySelector('input[type="range"]').name] = document.querySelector('input[type="range"]').value;

	//save checkboxes
	let itemsCheck = document.querySelectorAll('input[type="checkbox"]');
	for (let i = 0; i < itemsCheck.length; i++) {
		newSettings[itemsCheck[i].name] = itemsCheck[i].checked;
	}

	//save selects
	let selects = document.querySelectorAll('select');
	selects.forEach(element => {
		newSettings[element.name] = element.value;
	});

	//save favicon radio buttons
	let radio = document.querySelectorAll('input[type="radio"][name="favicon"]');
	for (let i = 0; i < radio.length; i++) {
		if (radio[i].checked) {
			newSettings[radio[i].name] = radio[i].value;
		}
	}

	//save logo radio buttons
	let logo = document.querySelectorAll('input[type="radio"][name="classicLogoChoice"]');
	for (let i = 0; i < logo.length; i++) {
		if (logo[i].checked) {
			newSettings[logo[i].name] = logo[i].value;
		}
	}

	//save buttons
	let buttons = document.querySelectorAll('fieldset button');
	for (let i = 0; i < buttons.length; i++) {
		newSettings[buttons[i].name] = buttons[i].value;
	}

	chrome.storage.sync.set({reduxSettings: newSettings});
	currentSettings = newSettings;
}

function changeGridWidth() {
	if (globalURL == "https://www.youtube.com/" || globalURL == "http://www.youtube.com/") {
		chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
			chrome.scripting.executeScript(
				{
					target: {tabId: tabs[0].id},
					function: () => {
						chrome.storage.sync.get(['reduxSettings'], function(result) {
							if (result) {
								let styleItem = document.querySelector("#primary > ytd-rich-grid-renderer #contents");
								styleItem.style.setProperty("--ytd-rich-grid-items-per-row", result.reduxSettings.gridItems, "important");	
							}
						});
					}
				}
			);
		});
	}
}

function getSettings() {
	if (currentSettings == null) {return;}
	let itemsCheck = document.querySelectorAll('input[type="checkbox"]');

	//set slider
	document.querySelector('input[type="range"]').value = currentSettings.gridItems;
	document.querySelector('.slider-control').value = currentSettings.gridItems;
	//set checkboxes
	for (let i = 0; i < itemsCheck.length; i++) {
		for (let j = 0; j < Object.keys(currentSettings).length; j++) {
			if (itemsCheck[i].name == Object.keys(currentSettings)[j]) {
				itemsCheck[i].checked = Object.values(currentSettings)[j];
			}
		}
	}
	//set selects
	document.querySelector('select[name="smallPlayerWidth"]').value = currentSettings.smallPlayerWidth == undefined ? 853 : currentSettings.smallPlayerWidth;
	if (document.querySelector('select[name="smallPlayerWidth"]').value == "") document.querySelector('select[name="smallPlayerWidth"]').value = "Custom";
	document.querySelector('select[name="titleFontValue"]').value = currentSettings.titleFontValue == undefined ? "Arial" : currentSettings.titleFontValue;
	if (document.querySelector('select[name="titleFontValue"]').value == "") document.querySelector('select[name="titleFontValue"]').value = "Custom";
	//set radio buttons
	document.querySelector(`input[type="radio"][value="${currentSettings.favicon}"]`).checked = true;
	document.querySelector(`input[type="radio"][value="${currentSettings.classicLogoChoice}"]`).checked = true;
	//uncheck subsettings
	let settingsElements = document.querySelectorAll('.settings:not(.slider-control)');
	for (let i = 0; i < settingsElements.length; i++) {
		if (settingsElements[i].parentElement.nextElementSibling != null && settingsElements[i].parentElement.nextElementSibling.classList.contains('subsettings-container')) {
			let subsettings = settingsElements[i].parentElement.nextElementSibling.querySelectorAll('.subsetting input[type="checkbox"]');
			if (settingsElements[i].checked) {
				subsettings.forEach(element => {
					element.removeAttribute('disabled');
				});
			}
		}
	}
}

function setPopupState() {
	calculateSizeOptions();
	getSettings();

	if (!currentSettings.completedSettingsTutorial) {
		document.querySelector('#right-arrow').classList.add("glow");
	}
}

function calculateSizeOptions() {
	let options = document.querySelectorAll('select[name="smallPlayerWidth"] option');
	options.forEach(element => {
		if (element.value == 'Custom') {
			element.innerText = `Custom...`; //fixed at 16:9
		} else {
			element.innerText = `${element.value}x${Math.ceil(element.value / 1.78)}px`; //fixed at 16:9
		}
	});
}

//main
chrome.storage.sync.get(['reduxSettings'], function(result) {
	if (result) {
		currentSettings = result.reduxSettings;
		setPopupState();
	}
});
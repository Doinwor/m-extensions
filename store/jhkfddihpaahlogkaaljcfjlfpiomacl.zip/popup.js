document.addEventListener('DOMContentLoaded', restoreOptions);

function saveOptions() {
    chrome.storage.local.set({
        youtube: document.getElementById('youtube').checked,
        vimeo: document.getElementById('vimeo').checked,
        html5: document.getElementById('html5').checked
    });
}

function restoreOptions() {
    chrome.storage.local.get({
        youtube: true,
        vimeo: true,
        html5: false
    }, function(items) {
        document.getElementById('youtube').checked = items.youtube;
        document.getElementById('youtube').addEventListener('change', saveOptions);

        document.getElementById('vimeo').checked = items.vimeo;
        document.getElementById('vimeo').addEventListener('change', saveOptions);

        document.getElementById('html5').checked = items.html5;
        document.getElementById('html5').addEventListener('change', saveOptions);

        const options = document.getElementsByClassName('option');
        for (let i = 0; i < options.length; i++) {
            options[i].style.visibility = 'visible';
        }
    });
}
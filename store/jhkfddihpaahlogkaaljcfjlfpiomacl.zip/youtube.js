// Создание политики для безопасной обработки HTML
window.trustedTypes.createPolicy('default', {
  createHTML: (input) => input // Здесь вы должны убедиться, что HTML безопасен
});
  

( async() => {
  var ytm = {
    /** @method */
    'getDuration': () => {
      var element = document.getElementById( 'movie_player' );
      return element.getDuration();
    },

    /** @method */
    'getTime': () => {
      return document.getElementById('movie_player').getCurrentTime();
    },
    
    /** @method */
    'setTime': ( time ) => {
      document.getElementById('movie_player').seekTo( time );
    },
    
    /** @method */
    'play': () => {
      document.getElementById('movie_player').playVideo();
    },
    
    /** @method */
    'pause': () => {
      document.getElementById('movie_player').pauseVideo();
    }
  };
  
  
  
  class Deferred extends Promise {
    #resolve;
    #reject;

    constructor(
      callback = ( resolve, reject ) => {}
    ) {
      let res, rej;

      super( ( resolve, reject ) => {
        res = resolve;
        rej = reject;
        callback( resolve, reject );
      });

      this.#resolve = res;
      this.#reject = rej;
    }

    resolve( result ) {
      this.#resolve( result );
      return this;
    }

    reject( error ) {
      this.#reject( error );
      return this;
    }
  };


  /** @function */
  var validateTimeString = ( time ) => {
    var broken = false;
    time = time.trim().replace( /\s/g, '' );
    
    if( !time ) broken = true;
    else if( !/\d+\:\d{1,2}\:\d{1,2}/.test( time ) && !/\d{1,2}\:\d{1,2}/.test( time ) ){
      broken = true;
    }
    
    if( !broken ){
      var parts = time.split( ':' );
      var seconds = Number( parts.at( -1 ) || 0 );
      var minutes = Number( parts.at( -2 ) || 0 );
      var hours = Number( parts.at( -3 ) || 0 ) ;
      
      var position = hours * 3600 + minutes * 60 + seconds;
      if( position < 0 ) broken = true;
    }
    
    if( broken ) return { 'valid': false };
    
    return { 'valid': true, position };
  };
  
  
  var videoElement = document.querySelector( '#movie_player video' );
  var videoChanges = new class{
    #listeners;
    
    constructor(){
      this.#listeners = [];
      
      var observer = new MutationObserver( (mutations) => {
        for( var mutation of mutations ){
          if (mutation.type === 'attributes' && mutation.attributeName === 'src') {
            for( var listener of this.#listeners ) listener();
          }
        }
      });

      observer.observe( videoElement, { attributes: true });
    }
    
    /** @method */
    addListener( listener ){
      this.#listeners.push( listener );
    }
  }();
  
  
  class YoutubeRepeatManipulator extends HTMLElement {
    #duration;
    #loopForChecked = false;
    #loopRangeChecked = false;
    #from;
    #to;
    #playCount = 0;
    #maxPlayCount = 10;

    #elementInputFrom;
    #elementInputTo;
    #elementLoopFor;
    #elementLoopRange;
    #elementPlayCount;
    #elementPointFrom;
    #elementPointTo;
    #elementTextFrom;
    #elementTextTo;
    #elementDecreaseMaxCount;
    #elementIncreaseMaxCount;
    #elementMaxCount;
    
    constructor() {
      super();
      
      this.#duration = 0;
      this.#from = 0;
      this.#to = this.#duration;
      
      var shadowRoot = this.attachShadow({ 'mode': 'closed' });
      
      shadowRoot.append( document.createElement( 'div' ) );

      shadowRoot.innerHTML = `
      <style>
      :host {
        display: block;
        font-size: 1.4rem!important;
      }

      input[type="checkbox"]{
        margin: 4px 0 0 0;
        float: left;
      }

      .PlayCount{
        padding: 0 0 7px;
      }

      .Columns{
        display: flex;
        padding: 0 0 7px;
      }
      .Columns > .L{
        flex-grow: 0;
      }
      .Columns > .R{
        flex-grow: 0;
      }

      .LoopFor{
        overflow: hidden;
        padding: 0 40px 0 0;
      }
      .LoopFor > .R{
        overflow: hidden;
        padding: 0 0 0 7px;
      }

      .LoopRange{
        overflow: hidden;
      }
      .LoopRange > .R{
        overflow: hidden;
        padding: 0 0 0 7px;
      }
      .LoopRange_Text{
        display: inline-block;
        vertical-align: top;
        padding: 2px 7px 0 0;
      }
      
      .Inputs{
        padding: 0 0 15px;
        display: inline-block;
        vertical-align: top;
      }
      .Inputs input[type="text"]{
        display: inline-block;
        vertical-align: top;
        width: 90px;
        text-align: center;
        border: 1px solid var(--yt-spec-text-disabled);
        background: transparent;
        color: inherit;
        font-size: inherit;
      }
      .Inputs input[type="text"] ~ input[type="text"]{
        margin-left: 7px;
      }
      
      .RangeSliderOut{
        padding: 0 10px 25px;
      }
      .RangeSlider{
        position: relative;
        background: var(--yt-spec-text-disabled);
        height: 2px;
      }
      .Point {
        width: 20px;
        height: 20px;
        background: var(--yt-spec-text-primary);
        position: absolute;
        top: -9px;
        cursor: pointer;
        border-radius: 50%;
        transform: translateX(-50%);
      }
      .PointClicker{
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
      }
      .Text{
        width: 70px;
        color: #fff;
        position: absolute;
        top: 21px;
        left: calc( 50% - 35px );
        text-align: center;
        font-family: 'Segoe UI', 'trebuchet ms',arial,sans-serif;
      }
      .Text > .In{
        background: #888;
        display: inline-block;
        vertical-align: top;
        padding: 0 4px;
        border-radius: 3px;
        user-select: none;
      }

      .Sign{
        background: var(--yt-spec-text-primary);
        padding: 0 4px;
        color: var(--yt-spec-base-background);
        cursor: pointer;
      }
      .InputMaxCount{
        border: 1px solid var(--yt-spec-text-disabled);
        background: transparent;
        color: inherit;
        font-size: inherit;
        width: 50px;
        text-align: center;
      }
      .LoopFor_Text{
        margin-right: 7px;
      }
      /*--yt-spec-10-percent-layer*/
      </style>
      
      <div class="PlayCount">
        Played <span id="PlayCount">${this.#playCount}</span> times
      </div>
      <div class="Columns">
        <div class="L">
          <div class="LoopFor">
            <input type="checkbox" id="LoopFor"/>
            <div class="R">
              <span class="LoopFor_Text">Loop for</span><!--
          --><span class="Sign" id="DecreaseMaxCount">&minus;</span>
              <input class="InputMaxCount" type="number" id="MaxCount" min="1" step="1"/>
              <span class="Sign" id="IncreaseMaxCount">&plus;</span>

              times
            </div>
          </div>
        </div>
        <div class="R">
          <div class="LoopRange">
            <input type="checkbox" id="LoopRange"/>
            <div class="R"><!--
          --><div class="LoopRange_Text">Loop a portion</div><!--
          --><div class="Inputs"><!--
              --><input type="text" id="from"/><!--
              --><input type="text" id="to"/><!--
            --></div>
            </div>
          </div>
        </div>
      </div>
      <div class="RangeSliderOut"><div class="RangeSlider">
        <div class="Point" id="PointLeft">
          <div class="Text"><div class="In"></div></div>
          <div class="PointClicker"></div>
        </div>
        <div class="Point" id="PointRight">
          <div class="Text"><div class="In"></div></div>
          <div class="PointClicker"></div>
        </div>
      </div></div>`;
      
      // Define elements
      var parent = shadowRoot.querySelector( '.RangeSlider' );
      
      this.#elementLoopFor = shadowRoot.getElementById( 'LoopFor' );
      this.#elementLoopRange = shadowRoot.getElementById( 'LoopRange' );
      this.#elementPlayCount = shadowRoot.getElementById( 'PlayCount' );

      this.#elementPointFrom = shadowRoot.getElementById( 'PointLeft' );
      this.#elementPointTo = shadowRoot.getElementById( 'PointRight' );
      
      this.#elementTextFrom = this.#elementPointFrom.querySelector( '.Text > .In' );
      this.#elementTextTo = this.#elementPointTo.querySelector( '.Text > .In' );
      
      this.#elementInputFrom = shadowRoot.querySelector( '#from' );
      this.#elementInputTo = shadowRoot.querySelector( '#to' );

      this.#elementDecreaseMaxCount = shadowRoot.querySelector( '#DecreaseMaxCount' );
      this.#elementIncreaseMaxCount = shadowRoot.querySelector( '#IncreaseMaxCount' );
      this.#elementMaxCount = shadowRoot.querySelector( '#MaxCount' );

      
      var calculateNewPosition = ( mouseX ) => {
        const rect = parent.getBoundingClientRect();
        
        const newPosition = ( mouseX - rect.left ) / rect.width * this.#duration;
        
        const roundedPosition = Math.round( newPosition );
        
        return Math.max(0, Math.min( this.#duration, roundedPosition) );
      };
      
      // Set view
      this.#redrawStartTime();
      this.#redrawEndTime();

      this.#elementMaxCount.value = this.#maxPlayCount;

      // Event listeners
      this.#elementLoopFor.addEventListener( 'click', () => {
        this.#loopForChecked = this.#elementLoopFor.checked;

        var detail = this.#loopForChecked
          ? this.#maxPlayCount
          : undefined;
        this.dispatchEvent( new CustomEvent( 'limit_change', { detail }) );
      });
      this.#elementLoopRange.addEventListener( 'click', () => {
        this.#loopRangeChecked = this.#elementLoopRange.checked;

        var detail = this.#loopRangeChecked
          ? {
            'from': this.#from,
            'to': this.#to
          }
          : undefined;
        this.dispatchEvent( new CustomEvent( 'range_change', { detail }) );
      });
      
      this.#elementPointFrom.querySelector( '.PointClicker' ).addEventListener( 'mousedown', ( event ) => {
        if( event.button !== 0 ) return;
        moveSlider( 'left' );
      });
      this.#elementPointTo.querySelector( '.PointClicker' ).addEventListener( 'mousedown', ( event ) => {
        if( event.button !== 0 ) return;
        moveSlider( 'right' );
      });
      
      this.#elementInputFrom.addEventListener( 'keydown', event => {
        event.stopPropagation();
      });
      this.#elementInputFrom.addEventListener( 'blur', () => {
        var { valid, position } = validateTimeString( this.#elementInputFrom.value );
        if( valid && position >= this.#to ) valid = false;
        
        if( !valid ){
           this.#elementInputFrom.value = this.#convertTimeToView( this.#from );
           return;
        }
        
        this.#from = position;

        this.#redrawStartTime();

        var detail = this.#loopRangeChecked
          ? {
            'from': this.#from,
            'to': this.#to
          }
          : undefined;
        this.dispatchEvent( new CustomEvent( 'range_change', { detail }) );
      });
      
      this.#elementInputTo.addEventListener( 'blur', () => {
        var { valid, position } = validateTimeString( this.#elementInputTo.value );
        if( valid && position <= this.#from ) valid = false;
        
        if( !valid ){
           this.#elementInputTo.value = this.#convertTimeToView( this.#to );
           return;
        }
        
        this.#to = position;

        this.#redrawEndTime();

        var detail = this.#loopRangeChecked
          ? {
            'from': this.#from,
            'to': this.#to
          }
          : undefined;
        this.dispatchEvent( new CustomEvent( 'range_change', { detail }) );
      });
      this.#elementInputTo.addEventListener( 'keydown', event => {
        event.stopPropagation();
      });

      this.#elementDecreaseMaxCount.addEventListener( 'click', event => {
        event.preventDefault();

        if( this.#maxPlayCount === 1 ) return;

        this.#maxPlayCount--;
        this.#elementMaxCount.value = this.#maxPlayCount;

        var detail = this.#loopForChecked
          ? this.#maxPlayCount
          : undefined;
        this.dispatchEvent( new CustomEvent( 'limit_change', { detail }) );
      });

      this.#elementIncreaseMaxCount.addEventListener( 'click', event => {
        event.preventDefault();

        this.#maxPlayCount++;
        this.#elementMaxCount.value = this.#maxPlayCount;

        var detail = this.#loopForChecked
          ? this.#maxPlayCount
          : undefined;
        this.dispatchEvent( new CustomEvent( 'limit_change', { detail }) );
      });

      this.#elementMaxCount.addEventListener( 'keydown', event => {
        event.stopPropagation();
      });
      this.#elementMaxCount.addEventListener( 'blur', () => {
        var value = this.#elementMaxCount.value;

        if( !/\d+/.test( value ) ){
          this.#elementMaxCount.value = this.#maxPlayCount;
          return;
        }

        var maxPlayCount = Number( value );
        if( maxPlayCount < 1 ){
          this.#elementMaxCount.value = this.#maxPlayCount;
          return;
        }

        this.#maxPlayCount = maxPlayCount;
        var detail = this.#loopForChecked
          ? this.#maxPlayCount
          : undefined;
        this.dispatchEvent( new CustomEvent( 'limit_change', { detail }) );
      });
      
      var moveSlider = ( whichPointer ) => {
        var onMouseMove = ( event ) => {
          var newPosition = calculateNewPosition( event.clientX );
          
          if( whichPointer === 'left' ){
            if( newPosition >= this.#to ) return;
          }
          else if( whichPointer === 'right' ){
            if( newPosition <= this.#from ) return;
          }
          
          if( whichPointer === 'left' ){
            this.#from = newPosition;
            this.#redrawStartTime();
          }
          else {
            this.#to = newPosition;
            this.#redrawEndTime();
          }
        };
        var onMouseUp = () => {
          document.removeEventListener( 'mousemove', onMouseMove );
          document.removeEventListener( 'mouseup', onMouseUp );

          var detail = this.#loopRangeChecked
            ? {
              'from': this.#from,
              'to': this.#to
            }
            : undefined;
          this.dispatchEvent( new CustomEvent( 'range_change', { detail }) );
        };

        document.addEventListener( 'mousemove', onMouseMove );
        document.addEventListener( 'mouseup', onMouseUp );
      }
    }
    
    /** @method */
    #convertTimeToView( time ){
      var showHours = this.#duration >= 3600;
      
      var seconds = time % 60;
      time -= seconds;
      
      var minutes = ( time / 60 ) % 60;
      time -= minutes * 60;
      
      var hours = time / 3600;
      
      var output = '';
      if( showHours ) output += hours + ':';
      output += String( minutes ).padStart( showHours ? 2 : 1, '0') + ':';
      output += String( seconds ).padStart( 2, '0' );
      
      return output;
    }
    
    /** @method */
    #redrawStartTime(){
      this.#elementTextFrom.textContent = this.#convertTimeToView( this.#from );
      this.#elementInputFrom.value = this.#convertTimeToView( this.#from );

      var percent = 100 * this.#from / this.#duration;
      this.#elementPointFrom.style.cssText = `left:${percent}%;`;
    }
    
    /** @method */
    #redrawEndTime(){
      this.#elementTextTo.textContent = this.#convertTimeToView( this.#to );
      this.#elementInputTo.value = this.#convertTimeToView( this.#to );

      var percent = 100 * this.#to / this.#duration;
      this.#elementPointTo.style.cssText = `left:${percent}%;`;
    }
    
    set duration( value ){
      this.#duration = value;
      
      this.#from = 0;
      this.#to = this.#duration;

      this.#redrawStartTime();
      this.#redrawEndTime();
    }

    /** @method */
    clear(){
      this.#loopForChecked = false;
      this.#loopRangeChecked = false;

      this.#elementLoopFor.checked = false;
      this.#elementLoopRange.checked = false;

      this.#playCount = 0;
      this.#elementPlayCount.textContent = '0';

      this.#maxPlayCount = 10;
      this.#elementMaxCount.value = 10;
    }

    set playCount( value ){
      this.#playCount = value;
      this.#elementPlayCount.textContent = value;
    }
  };
  customElements.define( 'youtube-repeat-manipulator', YoutubeRepeatManipulator );

  var div = document.createElement( 'div' );
  div.style.cssText = 'padding: 7px 0 0; width: calc(100% - 12px);';

  var divChildren = document.createElement( 'div' );
  divChildren.style.cssText =
    'border-radius: 12px;background: var(--yt-spec-badge-chip-background);padding: 12px;';
  
  var manipulator = new YoutubeRepeatManipulator(); //document.createElement( 'youtube-repeat-manipulator' );
  divChildren.prepend( manipulator );
  div.prepend( divChildren );
  
  
  var prmsInitiated = new Deferred();
  
  videoChanges.addListener( () => {
    div.remove();

    var duration = ytm.getDuration();
    manipulator.duration = Math.floor( duration );
    manipulator.clear();

    repeater.clear();
  });

  var repeater = new class{
    #block;
    #limit;
    #playCount = 0;
    #range;
    #duration;
    #seekListener;

    constructor( duration ){
      this.#duration = duration;

      manipulator.addEventListener( 'limit_change', ({ detail }) => {
        this.#limit = detail;
      });
      manipulator.addEventListener( 'range_change', ({ detail }) => {
        this.#range = detail;
      });

      this.#seekListener = event => {
        const time = event.target.currentTime;

        if( !this.#range ){
          if( time >= this.#duration - 0.5 && !this.#block ){
            this.#increasePlayCount();
            this.#block = true;
            setTimeout( () => {
              this.#block = false;
            }, 2000 );

            if( typeof this.#limit === 'number' && this.#playCount >= this.#limit ){
              ytm.pause();
            }
          }
        }
        else{
          if( time < this.#range.from ) ytm.setTime( this.#range.from );
          if( time >= this.#range.to ){
            this.#increasePlayCount();

            if( typeof this.#limit === 'number' && this.#playCount >= this.#limit ){
              ytm.pause();
            }
            else{
              ytm.setTime( this.#range.from );
            }
          }
        }
      };
    }

    /** @method */
    clear(){
      this.#limit = undefined;
      this.#playCount = 0;
      this.#range = undefined;

      this.disableSeekListener();
    }

    /** @method */
    #increasePlayCount(){
      this.#playCount++;
      
      manipulator.playCount = this.#playCount;
    }

    /** @method */
    enableSeekListener(){
      videoElement.addEventListener( 'timeupdate', this.#seekListener );
    }

    /** @method */
    disableSeekListener(){
      videoElement.removeEventListener( 'timeupdate', this.#seekListener );
    }

    set duration( value ){
      this.#duration = value;
    }
    set limit( value ){
      this.#limit = value;
    }
    set range( value ){
      this.#range = value;
    }
  }( ytm.getDuration() );

  
  window.addEventListener( 'message', ( event ) => {
    if( event.data?.type === 'ytm_initiated' ) prmsInitiated.resolve();
    
    if( event.data?.type === 'ytm_hide' ){
      div.remove();
      repeater.clear();
    }
    else if( event.data?.type === 'ytm_show' ){
      var duration = ytm.getDuration();
      manipulator.clear();
      manipulator.duration = Math.floor( duration );

      repeater.enableSeekListener();
      
      document.querySelector( '#bottom-row' ).prepend( div );
    }
  });
})();
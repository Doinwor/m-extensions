function getLoopSVG() {
  const e = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  e.setAttribute("viewBox", "0 0 24 24");
  const t = document.createElementNS("http://www.w3.org/2000/svg", "path");
  return t.setAttribute("d", "M12 6v3l4-4-4-4v3c-4.42 0-8 3.58-8 8 0 1.57.46 3.03 1.24 4.26L6.7 14.8c-.45-.83-.7-1.79-.7-2.8 0-3.31 2.69-6 6-6zm6.76 1.74L17.3 9.2c.44.84 .7 1.79 .7 2.8 0 3.31-2.69 6-6 6v-3l-4 4 4 4v-3c4.42 0 8-3.58 8-8 0-1.57-.46-3.03-1.24-4.26z"), e.appendChild(t), e
}

function detectVideoPlatform() {
    const e = window.location.hostname;
    return e.includes("youtube.com") ? "youtube" : e.includes("youtube-nocookie.com") ? "youtube-embed" : e.includes("vimeo.com") ? "vimeo" : null
}

function videoElementPresent() {
    let video = document.querySelector('video');
    return video && (video.hasAttribute('src') || video.getElementsByTagName('source').length > 0);
}

async function init() {
    setTimeout((videoElementPresent()) ? addLoop : init, 1500)
}

function addLoop() {
    chrome.storage.local.get({
        youtube: true,
        vimeo: true,
        html5: false
    }, function(items) {
        const e = detectVideoPlatform();
        if (items.youtube && e === "youtube") {
            insertLoopElementYoutube();
        } else if (items.youtube && e === "youtube-embed") {
            insertLoopElementYoutubeEmbed();
        } else if (items.vimeo && e === "vimeo") {
            insertLoopElementVimeo();
        } else if (items.html5) {
            addGenericLoopButton();
        }
        addObserver();
    });
}

var createLoopButton = () => {
  const e = document.createElement("a");
  
  e.classList.add("loop-button");
  e.title = "Loop Video";
  e.appendChild( getLoopSVG() );
  e.addEventListener("click", toggleLoopState);
  
  return e;
};

var insertLoopElementYoutube = () => {
  const e = createLoopButton();
  e.classList.add("ytp-button");
  
  const t = document.querySelector(".ytp-mute-button");
  t ? t.parentNode.insertBefore(e, t) : document.querySelector("div.ytp-left-controls").appendChild(e);
  
  appendYoutubeControls( e );
}

function insertLoopElementYoutubeEmbed() {
  const e = createLoopButton();
  e.style.cssText = "position:absolute;z-index:9999;cursor:pointer", waitForPlayerControlsThen(() => {
      const t = document.querySelector("button.ytp-mute-button");
      t ? (t.parentNode.parentNode.insertBefore(e, t.parentNode), e.style.top = `${t.getBoundingClientRect().top}px`, e.style.left = `${t.getBoundingClientRect().left - 40}px`) : (e.style.cssText = "position: absolute; right: 50px; top: 10px; z-index: 9999; cursor: pointer;", document.querySelector("body").appendChild(e))
  })
}

function waitForPlayerControlsThen(e) {
    document.querySelector("button.ytp-mute-button") ? e() : setTimeout(() => {
        waitForPlayerControlsThen(e)
    }, 500)
}

function insertLoopElementVimeo() {
    waitForVimeoControlsThen(e => {
        const t = createLoopButton();
        t.style.width = "50px";
        t.style.height = "32px";
        t.style.cursor = "pointer";
        t.style.backgroundColor = "#000000e6";

        e.appendChild(t)
    })
}

function waitForVimeoControlsThen(e) {
    const t = document.querySelector(".vp-controls");
    t ? e(t) : setTimeout(() => {
        waitForVimeoControlsThen(e)
    }, 500)
}

var updateToggleControls = () => {
  const repeatButton = document.querySelector(".loop-button");
  const video = document.querySelector("video");

  if (video.loop) {
      repeatButton.classList.add("active");
  } else {
      repeatButton.classList.remove("active");
  }

  repeatButton.title = video.loop ? "Stop Looping" : "Loop Video";
}

function addObserver() {
    const e = document.querySelector("video");
    new MutationObserver(() => {
      updateLoopStateFromVideo();
    }).observe(
      document.querySelector("video"), 
      {attributes: true, attributeFilter: ["loop"]}
    );
}

function addGenericLoopButton() {
  const video = document.querySelector('video');
  if (video) {
    const container = video.parentNode;
    const button = createLoopButton();
    button.style.width = "50px";
    button.style.height = "32px";
    button.style.cursor = "pointer";
    button.style.backgroundColor = "#000000e6";
    button.style.position = "absolute";
    button.style.top = "0px";
    button.style.right = "0px";
    button.style.display = 'none';
    container.appendChild(button);

    setTimeout(function() {
        button.style.display = 'block';
    }, 100);

    setTimeout(function() {
        if (!container.matches(':hover')) {
            button.style.display = 'none';
        }
    }, 3000);

    container.addEventListener('mouseenter', function() {
        button.style.display = 'block';
    });

    container.addEventListener('mouseleave', function() {
        button.style.display = 'none';
    });
  }
}

function updateLoopStateFromVideo() {
  const video = document.querySelector("video");
  const repeatButton = document.querySelector(".loop-button");
  if (video.loop) {
      repeatButton.classList.add("active");
  } else {
      repeatButton.classList.remove("active");
  }
}


var loopState = new class{
  #on;
  #listeners;
  
  constructor(){
    this.#on = false;
    this.#listeners = [];
  }
  
  /** @method */
  addListener( listener ){
    this.#listeners.push( listener );
  }
  
  /** @method */
  removeListener( listener ){
    this.#listeners = this.#listeners.filter( item => item !== listener );
  }
  
  /** @method */
  set( value ){
    if( this.#on === value ) return;
    
    this.#on = value;
    
    for( var listener of this.#listeners ) listener( value );
  }

  /** @method */
  toggle(){
    this.set( !this.#on );
  }
}();


/** @function */
var toggleLoopState = () => {
  const video = document.querySelector( "video" );
  video.loop = !video.loop;
  loopState.set( video.loop );
  if( video.loop ) video.play();
  
  updateToggleControls();
  updateLoopStateFromVideo();
};

var interceptYouTubeLoopControl = () => {
  const loopControls = document.querySelectorAll( '.ytp-menuitem-label' );

  for( var control of loopControls ){
    if( control.textContent.trim() !== 'Loop' ) continue;

    control.closest('.ytp-menuitem').addEventListener( 'click', () => {
      updateRepeatButtonState();
    });
  }
};

document.addEventListener('DOMContentLoaded', interceptYouTubeLoopControl);

var updateRepeatButtonState = () => {
  const video = document.querySelector("video");
  const repeatButton = document.querySelector(".loop-button");
  if (video && repeatButton) {
    if (video.loop) {
      repeatButton.classList.add("active");
    } 
    else {
      repeatButton.classList.remove("active");
    }
  }
}

const observer = new MutationObserver(mutations => {
  mutations.forEach(mutation => {
    if (mutation.attributeName === 'loop') {
      updateRepeatButtonState();

      loopState.set( video.loop );
    }
  });
});

var video = document.querySelector('video');
if (video) {
  observer.observe( video, { attributes: true });
}

init();





var youtubeControlsInitiated = false;

/** @function */
var appendYoutubeControls = async() => {
  if( !youtubeControlsInitiated ){
    youtubeControlsInitiated = true;

    var videoElement = document.querySelector( '#movie_player video' );
    
    var script = document.createElement( 'script' );
    script.src = chrome.runtime.getURL( 'youtube.js' );
    var prmsScriptLoaded = new Promise( ( resolve ) => {
      script.onload = () => { resolve(); };
    });
    ( document.head || document.documentElement ).appendChild( script );
    
    await prmsScriptLoaded;
    
    window.postMessage({ 'type': 'ytm_initiated' }, '*' );


/*
    var prmsScriptLoaded = new Promise( resolve => {
      script.addEventListener( 'load', resolve );
    });
    
    ( document.head || document.documentElement ).appendChild( script );

    await prmsScriptLoaded;

    var ytm = {
      'getDuration': async() => {
        var promise = new Promise( resolve => {
          var listener = ( event ) => {
            //window.removeEventListener( 'message', listener );
          };
          
          window.addEventListener( 'message', listener );

        });

        window.postMessage({ 'type': 'ytm_request_duration' }, '*' );

        return promise;
      }
    };*/
  }

  
  var videoChanges = new class{
    #listeners;
    
    constructor(){
      this.#listeners = [];
      
      var observer = new MutationObserver( (mutations) => {
        for( var mutation of mutations ){
          if (mutation.type === 'attributes' && mutation.attributeName === 'src') {
            for( var listener of this.#listeners ) listener();
          }
        }
      });

      observer.observe( videoElement, { attributes: true });
    }
    
    /** @method */
    addListener( listener ){
      this.#listeners.push( listener );
    }
  }();

  videoChanges.addListener( () => {
    loopState.set( false );
  });
  
  loopState.addListener( ( looped ) => {
    if( !looped ){
      window.postMessage({ 'type': 'ytm_hide' }, '*' );
      return;
    }
    
    window.postMessage({ 'type': 'ytm_show' }, '*' );
  });
};


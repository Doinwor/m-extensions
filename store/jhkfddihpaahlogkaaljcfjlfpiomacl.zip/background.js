chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    // Code to be executed on first install
    // eg. open a tab with a URL
    chrome.tabs.create({
      url: "https://milext.com/ytr-welcome?utm_source=extension&utm_medium=install",
    });
  } else if (details.reason === 'update') {
    // When the extension is updated
  } else if (details.reason === 'chrome_update') {
    // When the browser is updated
  } else if (details.reason === 'shared_module_update') {
    // When a shared module is updated
  }
});

const UNINSTALL_URL = "https://milext.com/ytr-uninstall?utm_source=extension&utm_medium=uninstall";
  chrome.runtime.setUninstallURL(UNINSTALL_URL);
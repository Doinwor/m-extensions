import{_ as r}from"./seventv.index.3.1.22.js";const e={};function t(c,n){return null}const o=r(e,[["render",t]]);export{o as default};

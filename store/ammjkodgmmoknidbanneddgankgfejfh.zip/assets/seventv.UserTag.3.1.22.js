import{u as ue,a as He}from"./seventv.useChatEmotes.3.1.22.js";import{f as ce,e as Y,x as l,l as c,m as y,G as B,_ as O,a2 as De,r as I,aH as Qe,u as M,O as $e,aA as be,a as re,i as It,S as St,a9 as Xe,W as mt,q as x,D as U,h as te,J as ht,F as z,B as V,I as Z,aC as Ot,w as ve,n as Le,C as fe,t as gt,E as se,d as vt,s as Ke,an as ft,P as Re,a1 as pe,N as X,H as We,Y as Be,ad as pt,av as Pt,aB as yt,M as xt,as as Et,Q as At,R as Rt,a3 as Bt,aI as Nt}from"./seventv.index.3.1.22.js";import{d as Ye,S as Ft}from"./seventv.useCosmetics.3.1.22.js";import{t as Vt,u as Q,D as Ht,l as le,j as Wt,F as Ce,L as Yt,h as _t,r as zt,n as qt,k as jt,H as Gt,m as Qt}from"./seventv.GearsIcon.3.1.22.js";import{f as Ne,g as Xt}from"./seventv.Transform.3.1.22.js";import{C as Je}from"./seventv.ChatMessage.3.1.22.js";import{d as Kt,h as Jt,f as Zt}from"./seventv.index.3.1.222.js";import{d as ea}from"./seventv.Async.3.1.22.js";import{U as ta,u as aa}from"./seventv.UiConfirmPrompt.3.1.22.js";import{t as na,a as bt,b as wt,u as Ie,E as Ct,c as ra}from"./seventv.Emote.3.1.22.js";import{a as ze}from"./seventv.useModule.3.1.22.js";import{w as ee,x as sa,y as oa,G as Pe}from"./seventv.index.3.1.223.js";import{S as Ze}from"./seventv.StoreSubscribeButton.3.1.22.js";import{a as ia,u as la}from"./seventv.Settings.3.1.22.js";import{O as ua}from"./seventv.OpenLinkIcon.3.1.22.js";import{v as da}from"./seventv.v4.3.1.22.js";import{a as et}from"./seventv.useFloatContext.3.1.22.js";import{R as Fe}from"./seventv.ReactHooks.3.1.22.js";import{T as ca,U as ma}from"./seventv.UiDraggable.3.1.22.js";import{U as Mt}from"./seventv.UiScrollable.3.1.22.js";const tt=new WeakMap;function $t(a){let t=tt.get(a);return t||(t=ce({isDarkTheme:1,primaryColorHex:null,useHighContrastColors:!0,showTimestamps:!1,showModerationIcons:!1,hovering:!1,pauseReason:new Set(["SCROLL"]),currentChannel:{},imageFormat:"WEBP",twitchBadgeSets:{},blockedUsers:new Set,fontAprilFools:"unset"}),tt.set(a,t)),t}const ha={ref:"tooltip",class:"seventv-tooltip","tooltip-type":"badge"},ga=Y({__name:"BadgeTooltip",props:{alt:{}},setup(a){return(t,e)=>(l(),c("div",ha,[y("p",null,B(t.alt),1)],512))}}),va=O(ga,[["__scopeId","data-v-bfbc76a7"]]),fa={class:"seventv-chat-badge"},pa=["srcset","alt"],ya=Y({__name:"Badge",props:{alt:{},type:{},badge:{}},setup(a){const t=a,{t:e}=De(),r=I(""),n=I(""),s={twitch:u=>`${u.image1x} 1x, ${u.image2x} 2x, ${u.image4x} 4x`,picture:u=>`${u.profileImageURL.replace(Qe,"28x28")} 1.6x,
		${u.profileImageURL.replace(Qe,"70x70")} 3.8x`,app:u=>u.data.host.files.map((v,g)=>`https:${u.data.host.url}/${v.name} ${g+1}x`).join(", ")}[t.type](t.badge),i=I(),f={alt:t.alt};if(w(t.badge)){const u=parseInt(t.badge.version,10),v=parseInt(t.badge.data??"0",10),g=isNaN(u)?0:Math.max(Math.floor(u/1e3),0);if(v>0){const o=g>0?"badges.subscriber.tiered_months":"badges.subscriber.months";f.alt+=` (${e(o,v,{named:{tier:g,months:v}})})`}}const{show:m,hide:h}=be(va,f);function b(u){return u.kind==="BADGE"&&t.type==="app"}function w(u){return t.type==="twitch"&&"setID"in u&&(u.setID==="subscriber"||u.setID==="founder")}return b(t.badge)&&(r.value=t.badge.data.backgroundColor??""),typeof t.badge=="string"&&(n.value="25%"),(u,v)=>(l(),c("div",fa,[y("img",{ref_key:"imgRef",ref:i,srcset:M(s),alt:u.alt,style:$e({backgroundColor:r.value,borderRadius:n.value}),onMouseenter:v[0]||(v[0]=g=>M(m)(i.value)),onMouseleave:v[1]||(v[1]=g=>M(h)())},null,44,pa)]))}}),Me=O(ya,[["__scopeId","data-v-64a9e06f"]]),at=new Map;function nt(a,t=!0){const e=at.get(a),r=t&&e?e:new Audio,n=(i=1)=>{if(t&&e){e.volume=i,e.play();return}_a(a).then(f=>{r.src=f,r.volume=i,r.play(),at.set(a,r)})},s=()=>r.pause();return Vt(()=>{r.remove()}),{play:n,stop:s,audio:r}}async function _a(a){const t=await fetch(a);if(!t.ok)throw new Error(`HTTP error: ${t.status} - ${t.statusText}`);return URL.createObjectURL(await t.blob())}let Tt=!1;const ba=Q("chat.font-april-fools-2026",!1);re(ba,a=>{Tt=a},{immediate:!0});const rt=new WeakMap,xe=Q("highlights.custom"),wa=Q("highlights.sound_volume");function Ca(a){const t=Kt(),e=It(St,""),r=ce({ping:nt(e+"/sound/ping.ogg")});let n=rt.get(a);n||(n=ce({highlights:{}}),re(xe,_=>{if(n){for(const[C,p]of Object.entries(n.highlights))p.persist&&delete n.highlights[C];for(const[,C]of _)n.highlights[C.id]=C,f(C),m(C)}},{immediate:!0}),rt.set(a,n));const s=ea(function(){if(!n)return;const _=Array.from(Object.values(n.highlights)).filter(C=>C.persist).map(C=>[C.id,Xe({...C,soundFile:Xe(C.soundFile),soundDef:void 0,flashTitleFn:void 0})]);xe.value=new Map(_)},250);function i(_,C,p){if(!n)return{};const D=n.highlights[_]={...C,id:_,persist:p};return f(D),p&&(xe.value.set(_,mt(D)),s()),D}function f(_){var D;if(!_.soundFile){(D=_.soundPath)!=null&&D.startsWith("#")&&r[_.soundPath.slice(1)]&&(_.soundDef=r[_.soundPath.slice(1)]);return}const C=new Blob([_.soundFile.data],{type:_.soundFile.type}),p=URL.createObjectURL(C);return _.soundPath=p,_.soundDef=nt(p),p}function m(_){_.flashTitleFn=_.flashTitle?()=>` 💬 Highlight: ${_.label||_.pattern}`:void 0}function h(_){n&&(delete n.highlights[_],s())}function b(_,C){var F,j,L,d;if(!n)return!1;const p=n==null?void 0:n.highlights[_];if(!p)return!1;let D=!1;if(Tt==!1&&!C.historical&&Math.random()<.005)D=!0;else if(p.phrase||!p.phrase&&!p.username&&!p.badge)if(p.regexp){let T=p.cachedRegExp;if(!T)try{T=new RegExp(p.pattern,"i"),Object.defineProperty(p,"cachedRegExp",{value:T})}catch(k){return le.warn("<ChatHighlights>","Invalid regexp:",p.pattern??""),C.setHighlight("#878787","Error "+k.message),!1}D=T.test(C.body)}else p.pattern?D=p.caseSensitive?C.body.includes(p.pattern):C.body.toLowerCase().includes(p.pattern.toLowerCase()):typeof p.test=="function"&&(D=p.test(C));else p.username?D=((F=C.author)==null?void 0:F.displayName.toLowerCase())===((j=p.pattern)==null?void 0:j.toLowerCase()):p.badge&&(D=Object.keys(C.badges).indexOf(((L=p.pattern)==null?void 0:L.toLowerCase())??"")>-1&&Object.values(C.badges).indexOf(((d=p.version)==null?void 0:d.toLowerCase())??"")>-1);return D&&(C.setHighlight(p.color,p.label),p.soundDef&&!C.historical&&p.soundDef.play(wa.value/100),p.flashTitleFn&&!C.historical&&o(p,C)),D}const w=I(""),u=I(document.title);let v=0;const g=Ht(()=>{Jt(v++%2===0?w.value:u.value)},1e3,{immediate:!1,immediateCallback:!0});function o(_,C){!_.flashTitleFn||g.isActive.value||(u.value=document.title,w.value=_.flashTitleFn(C),g.resume(),Wt(t).toBe("visible").then(()=>{g.pause(),w.value="",document.title=u.value}))}function $(){return n?Ce(n.highlights):{}}function P(){if(!n)return{};const _=Object.fromEntries(Object.entries(n.highlights).filter(([,C])=>C.phrase===!0||!C.phrase&&!C.username&&!C.badge));return Ce(_)}function E(){if(!n)return{};const _=Object.fromEntries(Object.entries(n.highlights).filter(([,C])=>C.username===!0));return Ce(_)}function q(){if(!n)return{};const _=Object.fromEntries(Object.entries(n.highlights).filter(([,C])=>C.badge===!0));return Ce(_)}function N(_,C){if(!n)return;const p=n.highlights[_];p&&(n.highlights[C]=p,delete n.highlights[_],p.id=C,s())}return{define:i,remove:h,getAll:$,getAllPhraseHighlights:P,getAllUsernameHighlights:E,getAllBadgeHighlights:q,save:s,updateId:N,checkMatch:b,updateSoundData:f,updateFlashTitle:m}}const st=new WeakMap;function Se(a){let t=st.get(a);t||(t=ce({TWITCH:{onShowViewerCard:()=>{},onShowViewerWarnPopover:()=>{}},YOUTUBE:{},KICK:{},UNKNOWN:{}}),st.set(a,t));function e(s,i,f){t&&(t[s][i]=f)}function r(s,i,f){if(!t||!s||!s.currentTarget||!i)return!1;const m=s.currentTarget.getBoundingClientRect();return t[a.platform].onShowViewerCard(i,0,f,m.bottom),!0}function n(s,i,f){return!t||!s||!i?!1:(t[a.platform].onShowViewerWarnPopover(s,i,f),!0)}return{update:e,openViewerCard:r,openViewerWarnPopover:n}}const Ma=ee`
	query ViewerCard(
		$channelID: ID!
		$channelIDStr: String!
		$channelLogin: String!
		$giftRecipientLogin: String!
		$withStandardGifting: Boolean!
	) {
		activeTargetUser: user(login: $giftRecipientLogin) {
			id
		}
		targetUser: user(login: $giftRecipientLogin, lookupType: ALL) {
			id
			login
			bannerImageURL
			displayName
			displayBadges(channelID: $channelID) {
				...badge
				description
			}
			chatColor
			profileImageURL(width: 70)
			createdAt
			relationship(targetUserID: $channelID) {
				cumulativeTenure: subscriptionTenure(tenureMethod: CUMULATIVE) {
					months
					daysRemaining
				}
				followedAt
				subscriptionBenefit {
					id
					tier
					purchasedWithPrime
					gift {
						isGift
					}
				}
			}
			isModerator(channelID: $channelIDStr)
			stream {
				id
				game {
					id
					displayName
				}
				viewersCount
			}
		}
		channelUser: user(login: $channelLogin) {
			id
			login
			displayName
			subscriptionProducts {
				...subscriptionProduct
			}
			self {
				banStatus {
					isPermanent
				}
				isModerator
			}
		}
		currentUser {
			login
			id
		}
		channelViewer(userLogin: $giftRecipientLogin, channelLogin: $channelLogin) {
			id
			earnedBadges {
				...badge
				description
			}
		}
		channel(id: $channelID) {
			id
			moderationSettings {
				canAccessViewerCardModLogs
			}
		}
	}

	${na}
	${bt}
`,$a=ee`
	query ViewerCardModLogs($channelLogin: String!, $channelID: ID!, $targetID: ID!) {
		targetUser: user(id: $targetID) {
			id
			login
		}
		channelUser: user(login: $channelLogin) {
			id
			login
		}
		currentUser {
			login
			id
		}
		banStatus: chatRoomBanStatus(channelID: $channelID, userID: $targetID) {
			bannedUser {
				id
				login
				displayName
			}
			createdAt
			expiresAt
			isPermanent
			moderator {
				id
				login
				displayName
			}
			reason
		}

		viewerCardModLogs(channelID: $channelID, targetID: $targetID) {
			messages: messages(first: 1000) {
				... on ViewerCardModLogsMessagesError {
					code
				}
				... on ViewerCardModLogsMessagesConnection {
					pageInfo {
						hasNextPage
					}
					count
				}
			}
			bans: targetedActions(first: 99, type: BAN) {
				...modLogsTargetedActionsResultFragment
			}
			timeouts: targetedActions(first: 99, type: TIMEOUT) {
				...modLogsTargetedActionsResultFragment
			}
			unbans: targetedActions(first: 99, type: UNBAN) {
				...modLogsTargetedActionsResultFragment
			}
			untimeouts: targetedActions(first: 99, type: UNTIMEOUT) {
				...modLogsTargetedActionsResultFragment
			}
			warnings: targetedActions(first: 99, type: WARN) {
				...modLogsTargetedActionsResultFragment
			}
			comments(first: 100) {
				... on ModLogsCommentConnection {
					edges {
						cursor
						node {
							id
							timestamp
							text
							channel {
								id
							}
							author {
								id
								login
								displayName
								chatColor
							}
						}
					}
					pageInfo {
						hasNextPage
						hasPreviousPage
					}
				}
				... on ModLogsCommentsError {
					code
				}
				__typename
			}
		}
	}

	fragment modLogsTargetedActionsResultFragment on ModLogsTargetedActionsResult {
		__typename
		... on ModLogsTargetedActionsError {
			code
		}
		... on ModLogsTargetedActionsConnection {
			count
			pageInfo {
				hasNextPage
			}
			edges {
				cursor
				node {
					...modLogsTargetedActionFragment
				}
			}
		}
	}

	fragment modLogsTargetedActionFragment on ModLogsTargetedAction {
		id
		localizedLabel {
			fallbackString
			...modActionTokens
		}
		timestamp
		type
	}

	fragment modActionTokens on ModActionsLocalizedText {
		localizedStringFragments {
			...modActionText
		}
	}

	fragment modActionText on ModActionsLocalizedTextFragment {
		token {
			... on ModActionsLocalizedTextToken {
				text
			}
			... on User {
				displayName
				login
				id
			}
		}
	}
`,Ta=ee`
	#import "twilight/features/message/fragments/message-sender/sender-fragment.gql"
	#import "twilight/features/moderation/moderation-actions/hooks/use-get-mod-actions/mod-action-tokens-fragment.gql"
	query ViewerCardModLogsMessagesBySender($channelID: ID!, $senderID: ID!, $cursor: Cursor) {
		logs: viewerCardModLogs(channelID: $channelID, targetID: $senderID) {
			messages(first: 50, after: $cursor) {
				... on ViewerCardModLogsMessagesError {
					code
				}
				... on ViewerCardModLogsMessagesConnection {
					edges {
						...viewerCardModLogsMessagesEdgeFragment
					}
					pageInfo {
						hasNextPage
					}
				}
			}
		}
	}
	fragment viewerCardModLogsMessagesEdgeFragment on ViewerCardModLogsMessagesEdge {
		__typename
		node {
			...viewerCardModLogsCaughtMessageFragment
			...viewerCardModLogsChatMessageFragment
			...viewerCardModLogsModActionsMessageFragment
		}
		cursor
	}
	fragment viewerCardModLogsChatMessageFragment on ViewerCardModLogsChatMessage {
		id
		sender {
			id
			login
			chatColor
			displayName
			displayBadges(channelID: $channelID) {
				id
				setID
				version
				__typename
			}
			__typename
		}
		sentAt
		content {
			text
			fragments {
				text
				content {
					... on Emote {
						emoteID: id
						setID
						token
					}
					#mention
					... on User {
						id
					}
					__typename
				}
			}
			__typename
		}
	}
	fragment viewerCardModLogsCaughtMessageFragment on ViewerCardModLogsCaughtMessage {
		id
		status
		category
		sentAt
		resolvedAt
		content {
			text
			fragments {
				text
				content {
					... on Emote {
						emoteID: id
						setID
						token
					}
					... on User {
						id
					}
					__typename
				}
			}
			__typename
		}
		sender {
			id
			login
			chatColor
			displayName
			displayBadges(channelID: $channelID) {
				id
				setID
				version
			}
			__typename
		}
		resolver {
			...sender
		}
		__typename
	}

	fragment viewerCardModLogsModActionsMessageFragment on ViewerCardModLogsModActionsMessage {
		timestamp
		content {
			fallbackString
			...modActionTokens
		}
	}

	fragment modActionTokens on ModActionsLocalizedText {
		localizedStringFragments {
			...modActionText
		}
	}

	fragment modActionText on ModActionsLocalizedTextFragment {
		token {
			... on ModActionsLocalizedTextToken {
				text
			}
			... on User {
				displayName
				login
				id
			}
		}
	}

	fragment sender on User {
		id
		login
		displayName
		chatColor
		displayBadges {
			...badge
		}
	}

	${bt}
`,ka=ee`
	mutation createModComment($input: CreateModeratorCommentInput!) {
		createModeratorComment(input: $input) {
			comment {
				...modComment
			}
		}
	}

	${wt}
`;ee`
	mutation deleteModeratorComment($input: DeleteModeratorCommentInput!) {
		deleteModeratorComment(input: $input) {
			comment {
				...modComment
			}
		}
	}

	${wt}
`;const Ua={},Da={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 448 512",fill:"currentColor"},La=y("path",{d:"M224 0c-17.7 0-32 14.3-32 32V51.2C119 66 64 130.6 64 208v18.8c0 47-17.3 92.4-48.5 127.6l-7.4 8.3c-8.4 9.4-10.4 22.9-5.3 34.4S19.4 416 32 416H416c12.6 0 24-7.4 29.2-18.9s3.1-25-5.3-34.4l-7.4-8.3C401.3 319.2 384 273.9 384 226.8V208c0-77.4-55-142-128-156.8V32c0-17.7-14.3-32-32-32zm45.3 493.3c12-12 18.7-28.3 18.7-45.3H224 160c0 17 6.7 33.3 18.7 45.3s28.3 18.7 45.3 18.7s33.3-6.7 45.3-18.7z"},null,-1),Ia=[La];function Sa(a,t){return l(),c("svg",Da,Ia)}const Oa=O(Ua,[["render",Sa]]),Pa={},xa={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 640 512",fill:"currentColor"},Ea=y("path",{d:"M38.8 5.1C28.4-3.1 13.3-1.2 5.1 9.2S-1.2 34.7 9.2 42.9l592 464c10.4 8.2 25.5 6.3 33.7-4.1s6.3-25.5-4.1-33.7l-90.2-70.7c.2-.4 .4-.9 .6-1.3c5.2-11.5 3.1-25-5.3-34.4l-7.4-8.3C497.3 319.2 480 273.9 480 226.8V208c0-77.4-55-142-128-156.8V32c0-17.7-14.3-32-32-32s-32 14.3-32 32V51.2c-42.6 8.6-79 34.2-102 69.3L38.8 5.1zM406.2 416L160 222.1v4.8c0 47-17.3 92.4-48.5 127.6l-7.4 8.3c-8.4 9.4-10.4 22.9-5.3 34.4S115.4 416 128 416H406.2zm-40.9 77.3c12-12 18.7-28.3 18.7-45.3H320 256c0 17 6.7 33.3 18.7 45.3s28.3 18.7 45.3 18.7s33.3-6.7 45.3-18.7z"},null,-1),Aa=[Ea];function Ra(a,t){return l(),c("svg",xa,Aa)}const Ba=O(Pa,[["render",Ra]]),Na={},Fa={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 448 512",width:"1em",height:"1em",fill:"currentColor"},Va=y("path",{d:"M96 0L63.9 44.9C58.8 52.1 56 60.8 56 69.6V72c0 22.1 17.9 40 40 40s40-17.9 40-40V69.6c0-8.8-2.8-17.5-7.9-24.6L96 0zM224 0L191.9 44.9c-5.1 7.2-7.9 15.8-7.9 24.6V72c0 22.1 17.9 40 40 40s40-17.9 40-40V69.6c0-8.8-2.8-17.5-7.9-24.6L224 0zm95.9 44.9c-5.1 7.2-7.9 15.8-7.9 24.6V72c0 22.1 17.9 40 40 40s40-17.9 40-40V69.6c0-8.8-2.8-17.5-7.9-24.6L352 0 319.9 44.9zM128 176V144H64v32 48H0V350.8l29.2 15.3 60-28.6 7.1-3.4 7 3.5L160 366.1l56.8-28.4 7.2-3.6 7.2 3.6L288 366.1l56.8-28.4 7-3.5 7 3.4 60 28.6L448 350.8V224H384V176 144H320v32 48H256V176 144H192v32 48H128V176zM448 386.9l-21.3 11.2-7.1 3.7-7.2-3.4-60.2-28.6-57 28.5-7.2 3.6-7.2-3.6L224 369.9l-56.8 28.4-7.2 3.6-7.2-3.6-57-28.5L35.7 398.4l-7.2 3.4-7.1-3.7L0 386.9V512H448V386.9z"},null,-1),Ha=[Va];function Wa(a,t){return l(),c("svg",Fa,Ha)}const Ya=O(Na,[["render",Wa]]),za={},qa={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512",width:"1em",height:"1em",fill:"currentColor"},ja=y("path",{d:"M39.8 263.8L64 288 256 480 448 288l24.2-24.2c25.5-25.5 39.8-60 39.8-96C512 92.8 451.2 32 376.2 32c-36 0-70.5 14.3-96 39.8L256 96 231.8 71.8c-25.5-25.5-60-39.8-96-39.8C60.8 32 0 92.8 0 167.8c0 36 14.3 70.5 39.8 96z"},null,-1),Ga=[ja];function Qa(a,t){return l(),c("svg",qa,Ga)}const Xa=O(za,[["render",Qa]]),Ka={},Ja={class:"seventv-user-card-actions"};function Za(a,t){return l(),c("div",Ja)}const en=O(Ka,[["render",Za],["__scopeId","data-v-ac215262"]]);function Ml(a){return a.kind==="TEXT"}function tn(a){return a.kind==="LINK"}function an(a){return a.kind==="EMOTE"}function nn(a){return a.kind==="MENTION"}const rn=ee`
	mutation Chat_BanUserFromChatRoom($input: BanUserFromChatRoomInput!) {
		banUserFromChatRoom(input: $input) {
			ban {
				bannedUser {
					id
					login
					displayName
				}
				createdAt
				expiresAt
				isPermanent
				moderator {
					id
					login
					displayName
				}
				reason
			}
			error {
				code
				minTimeoutDurationSeconds
				maxTimeoutDurationSeconds
			}
		}
	}
`,sn=ee`
	mutation Chat_UnbanUserFromChatRoom($input: UnbanUserFromChatRoomInput!) {
		unbanUserFromChatRoom(input: $input) {
			ban {
				bannedUser {
					id
					login
					displayName
				}
				createdAt
				expiresAt
				isPermanent
				moderator {
					id
					login
					displayName
				}
			}
			error {
				code
			}
		}
	}
`,on=ee`
	mutation Chat_DeleteChatMessage($input: DeleteChatMessageInput!) {
		deleteChatMessage(input: $input) {
			responseCode
			message {
				id
				sender {
					id
					login
					displayName
				}
				content {
					text
				}
			}
		}
	}
`,ln=ee`
	mutation PinChatMessage($input: PinChatMessageInput!) {
		pinChatMessage(input: $input) {
			pinnedChatMessage {
				id
				pinnedMessage {
					id
				}
			}
			error {
				code
			}
		}
	}
`,un=ee`
	mutation ModUser($input: ModUserInput!) {
		result: modUser(input: $input) {
			channel {
				id
				login
			}
			target {
				id
				login
			}
			error {
				code
			}
		}
	}
`,dn=ee`
	mutation UnmodUser($input: UnmodUserInput!) {
		result: unmodUser(input: $input) {
			channel {
				id
				login
			}
			target {
				id
				login
			}
			error {
				code
			}
		}
	}
`;function qe(a,t){const e=Ie();function r(m,h){return e.value?e.value.mutate({mutation:rn,variables:{input:{channelID:a.id,bannedUserLogin:t,expiresIn:m,reason:h}}}):Promise.reject("Missing Apollo")}function n(){return e.value?e.value.mutate({mutation:sn,variables:{input:{channelID:a.id,bannedUserLogin:t}}}):Promise.reject("Missing Apollo")}function s(m,h){return e.value?e.value.mutate({mutation:ln,variables:{input:{channelID:a.id,messageID:m,durationSeconds:h,type:"MOD"}}}):Promise.reject("Missing Apollo")}function i(m,h){return e.value?e.value.mutate({mutation:h?dn:un,variables:{input:{channelID:a.id,targetID:m}}}):Promise.reject("Missing Apollo")}function f(m){return e.value?e.value.mutate({mutation:on,variables:{input:{channelID:a.id,messageID:m}}}):Promise.reject("Missing Apollo")}return{banUserFromChat:r,unbanUserFromChat:n,pinChatMessage:s,deleteChatMessage:f,setUserModerator:i}}const cn={},mn={width:"1em",height:"1em",version:"1.1",viewBox:"0 0 20 20",x:"0px",y:"0px",fill:"currentColor"},hn=y("g",null,[y("path",{"fill-rule":"evenodd",d:"M2 10a8 8 0 1116 0 8 8 0 01-16 0zm8 6a6 6 0 01-4.904-9.458l8.362 8.362A5.972 5.972 0 0110 16zm4.878-2.505a6 6 0 00-8.372-8.372l8.372 8.372z","clip-rule":"evenodd"})],-1),gn=[hn];function vn(a,t){return l(),c("svg",mn,gn)}const fn=O(cn,[["render",vn]]),pn={},yn={width:"1em",height:"1em",version:"1.1",viewBox:"0 0 20 20",x:"0px",y:"0px",fill:"currentColor"},_n=y("g",null,[y("path",{d:"M12 2H8v1H3v2h14V3h-5V2zM4 7v9a2 2 0 002 2h8a2 2 0 002-2V7h-2v9H6V7H4z"}),y("path",{d:"M11 7H9v7h2V7z"})],-1),bn=[_n];function wn(a,t){return l(),c("svg",yn,bn)}const Cn=O(pn,[["render",wn]]),Mn={},$n={width:"1em",height:"1em",version:"1.1",viewBox:"0 0 20 20",x:"0px",y:"0px",fill:"currentColor"},Tn=y("g",null,[y("path",{d:"M11 9.586V6H9v4.414l2.293 2.293 1.414-1.414L11 9.586z"}),y("path",{"fill-rule":"evenodd",d:"M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-2 0a6 6 0 11-12 0 6 6 0 0112 0z","clip-rule":"evenodd"})],-1),kn=[Tn];function Un(a,t){return l(),c("svg",$n,kn)}const Dn=O(Mn,[["render",Un]]),Ln={},In={width:"1em",height:"1em",version:"1.1",viewBox:"0 0 20 20",x:"0px",y:"0px",fill:"currentColor"},Sn=y("g",null,[y("path",{"fill-rule":"evenodd",d:"M10.954 3.543c-.422-.724-1.486-.724-1.908 0l-6.9 11.844c-.418.719.11 1.613.955 1.613h13.798c.844 0 1.373-.894.955-1.613l-6.9-11.844zM11 15H9v-2h2v2zm0-3H9V7h2v5z","clip-rule":"evenodd"})],-1),On=[Sn];function Pn(a,t){return l(),c("svg",In,On)}const xn=O(Ln,[["render",Pn]]),En={class:"seventv-chat-mod-buttons"},An=Y({__name:"ModIcons",props:{msg:{}},setup(a){var o,$,P,E,q;const t=a,e=ue(),r=Se(e),{banUserFromChat:n,deleteChatMessage:s}=qe(e,((o=t.msg.author)==null?void 0:o.username)??"");function i(){t.msg.author&&r.openViewerWarnPopover(t.msg.author.id,t.msg.author.username,0)}const f=I(),m=be(`Ban ${(($=t.msg.author)==null?void 0:$.username)??"???"}`),h=I(),b=be(`Timeout ${((P=t.msg.author)==null?void 0:P.username)??"???"}`),w=I(),u=be(`Warn ${((E=t.msg.author)==null?void 0:E.username)??"???"}`),v=I(),g=be(`Delete message by ${((q=t.msg.author)==null?void 0:q.username)??"???"}`);return(N,_)=>(l(),c("span",En,[N.msg.author&&!N.msg.author.isActor?(l(),c("span",{key:0,ref_key:"banRef",ref:f,onClick:_[0]||(_[0]=C=>M(n)(null)),onMouseenter:_[1]||(_[1]=C=>M(m).show(f.value)),onMouseleave:_[2]||(_[2]=C=>M(m).hide())},[x(fn)],544)):U("",!0),N.msg.author&&!N.msg.author.isActor?(l(),c("span",{key:1,ref_key:"timeoutRef",ref:h,onClick:_[3]||(_[3]=C=>M(n)("10m")),onMouseenter:_[4]||(_[4]=C=>M(b).show(h.value)),onMouseleave:_[5]||(_[5]=C=>M(b).hide())},[x(Dn)],544)):U("",!0),N.msg.author&&!N.msg.author.isActor?(l(),c("span",{key:2,ref_key:"warnRef",ref:w,onClick:_[6]||(_[6]=C=>i()),onMouseenter:_[7]||(_[7]=C=>M(u).show(w.value)),onMouseleave:_[8]||(_[8]=C=>M(u).hide())},[x(xn)],544)):U("",!0),y("span",{ref_key:"deleteRef",ref:v,onClick:_[9]||(_[9]=C=>M(s)(N.msg.id)),onMouseenter:_[10]||(_[10]=C=>M(g).show(v.value)),onMouseleave:_[11]||(_[11]=C=>M(g).hide())},[x(Cn)],544)]))}}),Rn=O(An,[["__scopeId","data-v-743de9d0"]]),Ee=Yt.Get();function Bn(a){const t=sa(oa,{errorPolicy:"all"}),e=ue(),r=He(e),n=ia();a||re(()=>e.user,u=>{var v,g;u&&(a=(g=(v=u.connections)==null?void 0:v.find(o=>o.platform===e.platform))==null?void 0:g.emote_set_id)},{immediate:!0});const s=te(()=>{if(a&&r.sets[a])return r.sets[a]}),i=te(()=>{var u;return n.user?e.id==n.platformUserID||(((u=e.user)==null?void 0:u.editors)??[]).some(v=>{var g;return v.id==((g=n.user)==null?void 0:g.id)})?!0:n.editAnySet:!1}),f=te(()=>n.token?i.value:!1),m=te(()=>i.value&&!n.token);async function h(u,v){var o;if(!a){Ee.error("No set ID found");return}const g=await t.mutate({action:"ADD",emote_id:u,id:a,name:v});if((o=g==null?void 0:g.errors)!=null&&o.length){const $=g.errors[0];throw new Pe($.message,$)}return g}async function b(u){var g;if(!a){Ee.error("No set ID found");return}const v=await t.mutate({action:"REMOVE",emote_id:u,id:a});if((g=v==null?void 0:v.errors)!=null&&g.length){const o=v.errors[0];throw new Pe(o.message,o)}return v}async function w(u,v){var o;if(!a){Ee.error("No set ID found");return}const g=await t.mutate({action:"UPDATE",emote_id:u,id:a,name:v});if((o=g==null?void 0:g.errors)!=null&&o.length){const $=g.errors[0];throw new Pe($.message,$)}return g}return ce({add:h,remove:b,rename:w,set:s,setID:a,canEditSet:f,needsLogin:m})}const Nn=["shrink"],Fn=["value","active","placeholder"],Vn=Y({__name:"EmoteAliasButton",props:{alias:{}},emits:["update:alias"],setup(a,{emit:t}){const e=t,r=I(!1),n=I();return(s,i)=>(l(),c("div",{class:"alias-button",shrink:!r.value},[y("input",{ref_key:"aliasRef",ref:n,value:s.alias,active:r.value,placeholder:r.value?"Alias":"...",onInput:i[0]||(i[0]=f=>e("update:alias",n.value.value)),onFocus:i[1]||(i[1]=f=>r.value=!0),onBlur:i[2]||(i[2]=f=>{s.alias===""&&(r.value=!1)})},null,40,Fn)],8,Nn))}}),Hn=O(Vn,[["__scopeId","data-v-1cf40ae2"]]),Wn={class:"emote-link-embed"},Yn=["blurred"],zn={class:"emote-preview"},qn={class:"description"},jn=["title"],Gn={key:0,class:"emote-owner"},Qn=["type"],Xn={key:0,class:"login-required"},Kn=Y({__name:"EmoteLinkEmbed",props:{emoteId:{}},setup(a){const t=a,e=`https://7tv.app/emotes/${t.emoteId}`,r=I(),n=I(""),s=I(!0),i=Bn(),f=la(),m=te(()=>{var g;return!!((g=i.set)!=null&&g.emotes.find(o=>o.id===t.emoteId))}),h={ADD:"add",REMOVE:"remove",CONFLICT:"conflict",LINK:"link"};async function b(){switch(u.value){case h.ADD:await i.add(t.emoteId,n.value!==""?n.value:void 0),n.value="";break;case h.REMOVE:await i.remove(t.emoteId);break;case h.CONFLICT:break;case h.LINK:window.open(e,"_blank");break}}const w=g=>(g.preventDefault(),f.open=!0,f.switchView("profile"),!1),u=te(()=>{var o;return!i.canEditSet||!r.value?h.LINK:m.value?h.REMOVE:((o=i.set)==null?void 0:o.emotes.find($=>{var P;return $.name===(n.value!==""?n.value:(P=r.value)==null?void 0:P.name)}))||n.value!==""&&!Ot.test(n.value)?h.CONFLICT:h.ADD});async function v(){const g=await fetch(`https://7tv.io/v3/emotes/${t.emoteId}`);if(!g.ok)return;const o=await g.json();o.lifecycle!==2&&(r.value={id:o.id,name:o.name,data:o},o.listed!==!1&&(s.value=!1))}return ht(v),(g,o)=>{var $,P;return l(),c(z,null,[y("div",Wn,[y("div",{class:"emote-link-container",blurred:s.value},[($=r.value)!=null&&$.data?(l(),c(z,{key:0},[y("a",{href:e,target:"_blank",class:"link"},[y("div",zn,[r.value?(l(),V(Ct,{key:0,emote:r.value},null,8,["emote"])):U("",!0)])]),y("div",qn,[y("p",{class:"emote-name",title:r.value.name},B(r.value.name),9,jn),r.value.data.owner?(l(),c("p",Gn,B(r.value.data.owner.display_name),1)):U("",!0)]),u.value===h.ADD||u.value===h.CONFLICT?(l(),V(Hn,{key:0,class:"alias-button",type:u.value,alias:n.value,"onUpdate:alias":o[0]||(o[0]=E=>n.value=E)},null,8,["type","alias"])):U("",!0),y("div",{class:"action-button",type:u.value,onClick:b},[u.value===h.LINK?(l(),V(ua,{key:0})):u.value===h.REMOVE?(l(),c(z,{key:1},[Z(" - ")],64)):(l(),c(z,{key:2},[Z(" + ")],64))],8,Qn)],64)):U("",!0)],8,Yn),(P=r.value)!=null&&P.data&&s.value?(l(),c("div",{key:0,class:"emote-unlisted-warning",onClick:o[1]||(o[1]=E=>s.value=!1)}," Emote is unlisted! Click to view. ")):U("",!0)]),M(i).needsLogin?(l(),c("div",Xn,[y("a",{href:"#",onClick:w}," Authenticate extension to manage emotes ")])):U("",!0)],64)}}}),Jn=O(Kn,[["__scopeId","data-v-3c067032"]]),Zn=["href"],er=Y({__name:"MessageTokenLink",props:{token:{}},setup(a){return(t,e)=>(l(),c("a",{href:t.token.content.url,target:"_blank",class:"link-part"},B(t.token.content.displayText),9,Zn))}}),tr={class:"mention-token"},ar=Y({__name:"MessageTokenMention",props:{token:{},msg:{}},setup(a){const t=a,e=t.token.content.displayText.charAt(0)==="@",r=e?t.token.content.displayText.slice(1):t.token.content.displayText;return(n,s)=>(l(),c("span",tr,[x(we,{user:n.token.content.user??{id:M(da)(),username:M(r).toLowerCase(),displayName:M(r),color:""},"is-mention":"","hide-at":!e,"hide-badges":""},null,8,["user","hide-at"])]))}}),nr=O(ar,[["__scopeId","data-v-20ced684"]]),rr={class:"seventv-chat-message-rich-embed"},sr=["href"],or={class:"seventv-chat-message-rich-embed-layout"},ir={class:"seventv-chat-message-rich-embed-layout-thumbnail"},lr=["src"],ur={class:"seventv-chat-message-rich-embed-layout-description"},dr={class:"seventv-chat-message-rich-embed-layout-description-title"},cr={key:0},mr={class:"seventv-chat-message-rich-embed-layout-description-author"},hr=Y({__name:"RichEmbed",props:{richEmbed:{}},setup(a){return(t,e)=>(l(),c("div",rr,[y("a",{href:t.richEmbed.request_url,target:"_blank",class:"seventv-chat-message-rich-embed-link"},[y("div",or,[y("div",ir,[y("img",{src:t.richEmbed.thumbnail_url,alt:"thumbnail"},null,8,lr)]),y("div",ur,[y("div",null,[y("p",dr,B(t.richEmbed.title),1)]),t.richEmbed.twitch_metadata.clip_metadata.id?(l(),c("div",cr,[y("p",mr," Clipped by "+B(t.richEmbed.author_name),1)])):U("",!0)])])],8,sr)]))}}),gr=O(hr,[["__scopeId","data-v-250b0388"]]),vr=ee`
	query ChatReplies($messageID: ID!, $channelID: ID!) {
		message(id: $messageID) {
			...messageFields
			replies {
				nodes {
					...messageFields
				}
				totalCount
			}
		}
	}

	${ra}
`,fr={},pr={fill:"currenColor",width:"1em",height:"1em",version:"1.1",viewBox:"0 0 16 16",x:"0px",y:"0px"},yr=y("g",null,[y("path",{d:"M5 6H7V8H5V6Z"}),y("path",{d:"M9 6H11V8H9V6Z"}),y("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M8 14L10 12H13C13.5523 12 14 11.5523 14 11V3C14 2.44772 13.5523 2 13 2H3C2.44772 2 2 2.44772 2 3V11C2 11.5523 2.44772 12 3 12H6L8 14ZM6.82843 10H4V4H12V10H9.17157L8 11.1716L6.82843 10Z"})],-1),_r=[yr];function br(a,t){return l(),c("svg",pr,_r)}const je=O(fr,[["render",br]]),wr={},Cr={width:"1em",height:"1em",version:"1.1",viewBox:"0 0 20 20",x:"0px",y:"0px"},Mr=y("path",{d:"M8.5 5.5L7 4L2 9L7 14L8.5 12.5L6 10H10C12.2091 10 14 11.7909 14 14V16H16V14C16 10.6863 13.3137 8 10 8H6L8.5 5.5Z"},null,-1),$r=[Mr];function Tr(a,t){return l(),c("svg",Cr,$r)}const kr=O(wr,[["render",Tr]]),Ur={class:"seventv-tray-header"},Dr={class:"seventv-tray-icon seventv-reply"},Lr={class:"seventv-tray-header-text"},Ir={key:0},Sr={key:1},Or={class:"seventv-tray-user-message-container"},Pr=Y({__name:"ReplyTray",props:{close:{type:Function},id:{},authorID:{},username:{},displayName:{},body:{},deleted:{type:Boolean},thread:{}},setup(a){const t=a,e=I(null),r=I([]),n=I([]),s=ue(),i=He(s),f=Ie();return ve(async()=>{var b;if(!f.value)return;const m=await f.value.query({query:vr,fetchPolicy:"no-cache",variables:{messageID:((b=t.thread)==null?void 0:b.id)??t.id,channelID:s.id}}).catch(w=>{le.error("failed to fetch chat replies",w.message)});if(!m||!m.data||!m.data.message)return;e.value=Ne(m.data.message);const h=[e.value,...m.data.message.replies.nodes.map(w=>Ne(w))];h.forEach(w=>{w.parent={author:{displayName:t.displayName??"",username:t.username??""},body:t.body,deleted:t.deleted,id:t.id,uid:t.authorID??"",thread:t.thread??null}}),n.value=h}),ve(()=>{const m=n.value.findIndex(b=>b.id===t.id),h=r.value.at(m);h&&Le(()=>h.scrollIntoView())}),(m,h)=>(l(),c(z,null,[y("div",Ur,[y("div",Dr,[n.value.length<=1?(l(),V(kr,{key:0})):(l(),V(je,{key:1}))]),y("div",Lr,[n.value.length<=1&&m.authorID?(l(),c("span",Ir,B(`Replying to @${m.displayName??m.username}:`),1)):(l(),c("span",Sr," Thread "))]),y("div",{class:"seventv-tray-icon seventv-close",onClick:h[0]||(h[0]=b=>m.close())},[x(ca)])]),x(Mt,null,{default:fe(()=>[y("div",Or,[(l(!0),c(z,null,se(n.value,b=>{var w;return l(),c("div",{key:b.id,ref_for:!0,ref_key:"msgElems",ref:r,class:"seventv-tray-user-message"},[x(Ve,{msg:b,emotes:M(i).active,"force-timestamp":!0,as:"Reply",class:gt(["thread-msg",{"is-root-msg":((w=e.value)==null?void 0:w.id)===b.id,"is-selected-msg":t.id===b.id&&n.value.length>1}])},null,8,["msg","emotes","class"])])}),128))])]),_:1})],64))}}),xr=O(Pr,[["__scopeId","data-v-10eb02d7"]]),ot=vt(new Set);function it(a,t){const e=vt({current:null}),r={parent:e,component:mt(a),props:t},n=re(e,s=>{s.current?ot.add(r):(ot.delete(r),n())});return{$$typeof:Fe,key:null,ref:e,type:"seventv-tray-container",props:{}}}function Er(a){const t=a;return!!(t.id&&t.body)&&typeof t.deleted=="boolean"}function Ar(a){var t;return{body:xr,inputValueOverride:"",sendButtonOverride:"reply",disableBits:!0,disablePaidPinnedChat:!0,disableChat:a.deleted||((t=a.thread)==null?void 0:t.deleted),sendMessageHandler:{type:"reply",additionalMetadata:{reply:{parentMsgId:a.id,parentMessageBody:a.body,...a.authorID?{parentUid:a.authorID,parentUserLogin:a.username,parentDisplayName:a.displayName}:{},...a.thread?{threadParentMsgId:a.thread.id,threadParentDeleted:a.thread.deleted,threadParentUserLogin:a.thread.login}:{}}}},type:"reply"}}function Rr(a,t){let e=null;switch(a){case"Reply":if(!Er(t))break;e=Ar(t)}return e}function Br(a,t,e,r=!1){const n=ze("chat-input"),s=r?"setModifierTray":"setTray";function i(){var m;!n.value||typeof((m=n.value.instance)==null?void 0:m[s])!="function"||n.value.instance[s](null)}function f(){var w;if(!n.value||typeof((w=n.value.instance)==null?void 0:w[s])!="function")return;const m=I(!0),h={...t==null?void 0:t(),close:()=>{m.value=!1,i()}};if(!h)return m.value=!1,m;const b=e??Rr(a,h);return b?(n.value.instance[s]({...b,header:b.header?it(b.header,h):void 0,body:b.body?it(b.body,h):void 0}),m):(m.value=!1,m)}return{open:f,clear:i,props:t,options:e}}function $l(a,t=!1){const e=Ke(null),r=Ke(null),i={type:"seventv-custom-tray",header:{$$typeof:Fe,key:"header",ref:u=>e.value=u,type:"seventv-tray-container-header",props:{}},body:{$$typeof:Fe,key:"body",ref:u=>r.value=u,type:"seventv-tray-container-body",props:{}},sendMessageHandler:a.messageHandler?{type:"custom-message-handler",handleMessage:a.messageHandler}:a.sendMessageHandler??void 0},f=t?"setModifierTray":"setTray",m=ze("chat-input");function h(u){var v;!((v=m.value)!=null&&v.instance)||typeof m.value.instance[f]!="function"||m.value.instance[f](u)}return ce({open:()=>h({...a,...i}),close:()=>h(),bodyRef:r,headerRef:e})}const Nr={},Fr={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 384 512",width:"1em",height:"1em",fill:"currentColor"},Vr=y("path",{d:"M320 448v40c0 13.255-10.745 24-24 24H24c-13.255 0-24-10.745-24-24V120c0-13.255 10.745-24 24-24h72v296c0 30.879 25.121 56 56 56h168zm0-344V0H152c-13.255 0-24 10.745-24 24v368c0 13.255 10.745 24 24 24h272c13.255 0 24-10.745 24-24V128H344c-13.2 0-24-10.8-24-24zm120.971-31.029L375.029 7.029A24 24 0 0 0 358.059 0H352v96h96v-6.059a24 24 0 0 0-7.029-16.97z"},null,-1),Hr=[Vr];function Wr(a,t){return l(),c("svg",Fr,Hr)}const Yr=O(Nr,[["render",Wr]]),zr={},qr={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 384 512",width:"1em",height:"1em",fill:"currentColor"},jr=y("path",{d:"M64 0H32V64H64 93.5L82.1 212.1C23.7 240.7 0 293 0 320v32H384V320c0-22.5-23.7-76.5-82.1-106.7L290.5 64H320h32V0H320 64zm96 480v32h64V480 384H160v96z"},null,-1),Gr=[jr];function Qr(a,t){return l(),c("svg",qr,Gr)}const Xr=O(zr,[["render",Qr]]),Kr={},Jr={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512",width:"1em",height:"1em",fill:"currentColor"},Zr=y("path",{d:"M0 208L192 384h32V288h80c61.9 0 112 50.1 112 112c0 48-32 80-32 80s128-48 128-176c0-97.2-78.8-176-176-176H224V32H192L0 208z"},null,-1),es=[Zr];function ts(a,t){return l(),c("svg",Jr,es)}const as=O(Kr,[["render",ts]]),ns={class:"seventv-copied-message-toast-body"},rs={key:0},ss=Y({__name:"UiCopiedMessageToast",props:{message:{}},emits:["close"],setup(a,{emit:t}){const e=I(),r=t;return Zt(e,()=>{r("close")}),(n,s)=>(l(),c("main",{ref_key:"copiedMessageToastRef",ref:e,class:"seventv-copied-message-toast"},[y("div",ns,[n.message?(l(),c("p",rs,B(n.message),1)):ft(n.$slots,"default",{key:1},void 0,!0)])],512))}}),os=O(ss,[["__scopeId","data-v-fbb0ba18"]]),is={class:"seventv-chat-message-buttons"},ls=Y({__name:"UserMessageButtons",props:{msg:{}},emits:["pin"],setup(a,{emit:t}){const e=a,r=t,n=Br("Reply",()=>{var o,$,P,E,q,N,_;return{id:e.msg.id,body:e.msg.body,deleted:e.msg.moderation.deleted,...e.msg.author?{authorID:(o=e.msg.author)==null?void 0:o.id,username:($=e.msg.author)==null?void 0:$.username,displayName:(P=e.msg.author)==null?void 0:P.displayName}:{},...e.msg.parent?{thread:{deleted:((E=e.msg.parent.thread)==null?void 0:E.deleted)??e.msg.parent.deleted,id:((q=e.msg.parent.thread)==null?void 0:q.id)??e.msg.parent.id,login:((N=e.msg.parent.thread)==null?void 0:N.login)??((_=e.msg.parent.author)==null?void 0:_.username)??""}}:{}}}),s=Q("chat.copy_icon_toggle"),i=I(!1),f=I(),m=et(f,{enabled:()=>i.value,middleware:[Re({padding:8})]});function h(){i.value||(navigator.clipboard.writeText(e.msg.body),i.value=!0,_t(()=>{i.value=!1},1e3))}const b=I(!1),w=I(),u=et(w,{enabled:()=>b.value,middleware:[Re({padding:8})]});function v(){n.open()}function g(o){o==="yes"&&r("pin")}return(o,$)=>{const P=pe("tooltip");return l(),c(z,null,[y("div",is,[M(s)&&!o.msg.moderation.deleted?X((l(),c("div",{key:0,ref_key:"copyButtonRef",ref:f,class:"seventv-button",onClick:$[0]||($[0]=E=>h())},[x(Yr)])),[[P,"Copy"]]):U("",!0),o.msg.pinnable&&!o.msg.moderation.deleted?X((l(),c("div",{key:1,ref_key:"pinButtonRef",ref:w,class:"seventv-button",onClick:$[1]||($[1]=E=>b.value=!0)},[x(Xr)])),[[P,"Pin"]]):U("",!0),X((l(),c("div",{class:"seventv-button",onClick:v},[(l(),V(We(o.msg.parent?je:as)))])),[[P,"Reply"]])]),i.value&&M(m)?(l(),V(Be,{key:0,to:M(m)},[x(os,{title:"Message Copied",onClose:$[2]||($[2]=E=>i.value=!1)},{default:fe(()=>[Z(" Message from "),o.msg.author?(l(),V(we,{key:0,user:o.msg.author},null,8,["user"])):U("",!0),Z(" has been copied ")]),_:1})],8,["to"])):U("",!0),b.value&&M(u)?(l(),V(Be,{key:1,to:M(u)},[x(ta,{title:"Pin Message?",choices:["yes","no"],onClose:$[3]||($[3]=E=>b.value=!1),onAnswer:$[4]||($[4]=E=>g(E))},{default:fe(()=>[Z(" Are you sure you want to pin this message by "),o.msg.author?(l(),V(we,{key:0,user:o.msg.author},null,8,["user"])):U("",!0),Z("? ")]),_:1})],8,["to"])):U("",!0)],64)}}}),us=O(ls,[["__scopeId","data-v-b7afb063"]]);function G(a,t){if(t.length<a)throw new TypeError(a+" argument"+(a>1?"s":"")+" required, but only "+t.length+" present")}function ds(a,t,e){var r;G(1,arguments);var n;return cs(t)?n=t:e=t,new Intl.DateTimeFormat((r=e)===null||r===void 0?void 0:r.locale,n).format(a)}function cs(a){return a!==void 0&&!("locale"in a)}function Ge(a,t){var e=arguments.length>2&&arguments[2]!==void 0?arguments[2]:[];return e.length>=t?a.apply(null,e.slice(0,t).reverse()):function(){for(var r=arguments.length,n=new Array(r),s=0;s<r;s++)n[s]=arguments[s];return Ge(a,t,e.concat(n))}}const ms=Ge(ds,3),hs=["msg-id","state","data-highlight-style"],gs=["data-highlight-label"],vs={key:1,class:"seventv-chat-message-timestamp"},fs={key:4},ps={class:"seventv-chat-message-body"},ys={key:0,class:"text-token"},_s={key:1},bs={key:0,class:"seventv-chat-message-moderated"},ws={key:1,class:"seventv-chat-message-moderated"},Cs=Y({__name:"UserMessage",props:{msg:{},as:{default:"Chat"},highlight:{},emotes:{},chatters:{},isModerator:{type:Boolean},hideAuthor:{type:Boolean},hideModeration:{type:Boolean},hideModIcons:{type:Boolean},hideDeletionState:{type:Boolean},showButtons:{type:Boolean},forceTimestamp:{type:Boolean}},setup(a){var D;const t=a,e=pt(t,"msg"),r=I(),n=ue(),s=$t(n),{openViewerCard:i}=Se(n),{pinChatMessage:f}=qe(n,((D=e.value.author)==null?void 0:D.username)??""),m=Q("chat.emote_scale"),h=Q("chat.slash_me_style"),b=Q("highlights.display_style"),w=Q("highlights.opacity"),u=Q("chat.timestamp_with_seconds"),v=Q("chat.show_emote_modifiers"),g=Q("chat.timestamp_format"),o=navigator.languages&&navigator.languages.length?navigator.languages[0]:navigator.language??"en",$=t.msg.author?Ye(t.msg.author.id):{emotes:{}},P=I(""),E=t.msg.getTokenizer(),q=I([]);function N(){if(!E)return;const R=E.tokenize({chatterMap:t.chatters??{},emoteMap:t.emotes??{},localEmoteMap:{...$.emotes,...t.msg.nativeEmotes},showModifiers:v.value}),F=[],j=t.msg.body;let L=0;for(const T of R){const k=T.range[0],S=T.range[1],H=j.substring(L,k);H&&F.push(H),F.push(T),L=S+1}const d=j.substring(L);d&&F.push(d),q.value=F}function _(){var R;(R=f(e.value.id,1200))==null||R.catch(F=>le.error("failed to pin chat message",F))}re(()=>[$.emotes,t.msg.nativeEmotes],()=>N(),{immediate:!0}),t.msg.refresh=N,t.msg.historical&&_t(ve(()=>{N()}),1e4);function C(R){if(nn(R))return nr;if(tn(R))return er}const p=()=>{switch(g.value){case"infer":return;case"12":return"h12";case"24":return"h23"}};return ve(()=>{!e.value||!r.value||(e.value.highlight&&(r.value.style.setProperty("--seventv-highlight-color",e.value.highlight.color),r.value.style.setProperty("--seventv-highlight-dim-color",e.value.highlight.color.concat(Ft(w.value/100)))),(s.showTimestamps||e.value.historical||t.forceTimestamp)&&(P.value=ms({locale:o},{localeMatcher:"lookup",hour:"2-digit",minute:"2-digit",second:u.value?"numeric":void 0,hourCycle:p()},t.msg.timestamp)))}),(R,F)=>{var j;return l(),c("span",{ref_key:"msgEl",ref:r,class:gt(["seventv-user-message",{deleted:!R.hideDeletionState&&(e.value.moderation.banned||e.value.moderation.deleted),"has-mention":R.as=="Chat"&&e.value.mentions.has("#actor"),"has-highlight":R.as=="Chat"&&e.value.highlight}]),"msg-id":e.value.id,state:e.value.deliveryState,style:$e({"font-style":e.value.slashMe&&M(h)&1?"italic":"",color:e.value.slashMe&&M(h)&2?(j=e.value.author)==null?void 0:j.color:""}),"data-highlight-style":M(b)},[e.value.highlight?(l(),c("div",{key:0,class:"seventv-chat-message-highlight-label","data-highlight-label":e.value.highlight.label},null,8,gs)):U("",!0),M(s).showTimestamps||e.value.historical||R.forceTimestamp?(l(),c("span",vs,B(P.value),1)):U("",!0),M(n).actor.roles.has("MODERATOR")&&M(s).showModerationIcons&&!R.hideModIcons?(l(),V(Rn,{key:2,msg:e.value},null,8,["msg"])):U("",!0),e.value.author&&!R.hideAuthor?(l(),V(we,{key:3,user:e.value.author,"source-data":e.value.sourceData,badges:e.value.badges,"badge-data":e.value.badgeData,"msg-id":e.value.sym,onOpenNativeCard:F[0]||(F[0]=L=>M(i)(L,e.value.author.username,e.value.id))},null,8,["user","source-data","badges","badge-data","msg-id"])):U("",!0),R.hideAuthor?U("",!0):(l(),c("span",fs,B(e.value.slashMe?" ":": "),1)),y("span",ps,[(l(!0),c(z,null,se(q.value,(L,d)=>(l(),c(z,{key:d},[typeof L=="string"?(l(),c("span",ys,B(L),1)):M(an)(L)?(l(),c("span",_s,[x(Ct,{class:"emote-token",emote:L.content.emote,format:M(s).imageFormat,overlaid:L.content.overlaid,clickable:!0,scale:Number(M(m))},null,8,["emote","format","overlaid","scale"]),L.content?(l(),c("span",{key:0,style:$e({color:L.content.cheerColor})},B(L.content.cheerAmount),5)):U("",!0)])):(l(),V(We(C(L)),Pt(yt({key:2},{token:L,msg:e.value})),null,16))],64))),128))]),e.value.richEmbed.request_url?(l(),V(gr,{key:5,"rich-embed":e.value.richEmbed},null,8,["rich-embed"])):U("",!0),e.value.emoteLinkEmbed?(l(),V(Jn,{key:6,"emote-id":e.value.emoteLinkEmbed},null,8,["emote-id"])):U("",!0),!R.hideModeration&&(e.value.moderation.banned||e.value.moderation.deleted)?(l(),c(z,{key:7},[e.value.moderation.banned?(l(),c("span",bs,B(e.value.moderation.banDuration?`Timed out (${e.value.moderation.banDuration}s)`:"Permanently Banned"),1)):(l(),c("span",ws,"Deleted"))],64)):U("",!0),x(us,{msg:e.value,onPin:F[1]||(F[1]=L=>_())},null,8,["msg"])],14,hs)}}}),Ve=O(Cs,[["__scopeId","data-v-2db31e35"]]),Ms={class:"seventv-chat-message-container"},$s={class:"seventv-chat-message-background",tabindex:"0"},Ts={key:0,class:"seventv-reply-part"},ks={class:"seventv-chat-reply-icon"},Us={class:"seventv-reply-message-part"},Ds=Y({__name:"0.NormalMessage",props:{msg:{},msgData:{}},setup(a){return(t,e)=>{const r=pe("tooltip");return l(),c("div",Ms,[y("div",$s,[t.msgData.reply?(l(),c("div",Ts,[y("div",ks,[x(je)]),X((l(),c("div",Us,[Z(B(`Replying to @${t.msgData.reply.parentDisplayName}: ${t.msgData.reply.parentMessageBody}`),1)])),[[r,`Replying to @${t.msgData.reply.parentDisplayName}: ${t.msgData.reply.parentMessageBody}`]])])):U("",!0),ft(t.$slots,"default",{},void 0,!0)])])}}}),Ls=O(Ds,[["__scopeId","data-v-7a7ddc21"]]),kt=a=>(At("data-v-21ba2f53"),a=a(),Rt(),a),Is={key:0,class:"seventv-user-card-message-timeline"},Ss=["timeline-id"],Os=kt(()=>y("div",{selector:"date-boundary"},null,-1)),Ps=kt(()=>y("div",{selector:"date-boundary"},null,-1)),xs={class:"seventv-user-card-message-timeline-list"},Es={key:1,class:"seventv-user-card-message-timeline-empty"},As={key:2,class:"seventv-user-card-mod-comment-input-container"},Rs=["placeholder","onKeydown"],Bs=Y({__name:"UserCardMessageList",props:{activeTab:{},target:{},timeline:{},scroller:{}},emits:["add-mod-comment"],setup(a,{emit:t}){const e=a,r=t,{t:n}=De(),s=ue(),i=He(s),f=zt(!0,10),m=Ie(),h=I("");function b(){var u;(u=e.scroller)!=null&&u.container&&e.scroller.container.scrollTo({top:e.scroller.container.scrollHeight})}async function w(){var g;if(!h.value||!m.value)return;const u=h.value;h.value="";const v=await m.value.mutate({mutation:ka,variables:{input:{channelID:s.id,targetID:e.target.id,text:u}}}).catch(o=>le.error("failed to add mod comment",o));!v||!v.data||!v.data.createModeratorComment||(r("add-mod-comment",(g=v.data)==null?void 0:g.createModeratorComment.comment),Le(b))}return re(()=>e.activeTab,()=>{f.value=!1,setTimeout(()=>{b()},10)}),re(e.timeline,()=>{var u;!((u=e.scroller)!=null&&u.container)||e.scroller.container.scrollTop!==0||b()}),(u,v)=>M(f)?(l(),c("div",Is,[Object.keys(e.timeline).length?(l(!0),c(z,{key:0},se(Object.entries(e.timeline).reverse(),([g,o])=>(l(),c("section",{key:g,"timeline-id":g},[Os,y("label",null,B(g),1),Ps,y("div",xs,[(l(!0),c(z,null,se(o,$=>(l(),c(z,{key:$.sym},[$.instance&&$.instance!==Ls?(l(),V(We($.instance),yt({key:0},$.componentProps,{msg:$}),{default:fe(()=>[x(Ve,{msg:$,emotes:M(i).active,"hide-mod-icons":!0,"force-timestamp":!0},null,8,["msg","emotes"])]),_:2},1040,["msg"])):(l(),V(Ve,{key:1,msg:$,emotes:M(i).active,"hide-mod-icons":!0,"force-timestamp":!0},null,8,["msg","emotes"]))],64))),128))])],8,Ss))),128)):(l(),c("div",Es,[y("p",null,B(M(n)(`user_card.no_${u.activeTab}`,{user:u.target.displayName})),1)])),u.activeTab==="comments"?(l(),c("div",As,[X(y("input",{id:"seventv-user-card-mod-comment-input","onUpdate:modelValue":v[0]||(v[0]=g=>h.value=g),placeholder:M(n)("user_card.add_comment_input_placeholder"),onKeydown:Et(w,["enter"])},null,40,Rs),[[xt,h.value]])])):U("",!0)])):U("",!0)}}),Ns=O(Bs,[["__scopeId","data-v-21ba2f53"]]),Fs={mlns:"http://www.w3.org/2000/svg",viewBox:"0 0 640 512",width:"1em",height:"1em",fill:"currentColor"},Vs={key:0,d:"M408 56L384 80c37.3 37.3 74.7 74.7 112 112c8-8 16-16 24-24l56 56c-37.5 37.5-74.9 74.9-112.4 112.4c59.1 45.9 118.2 91.7 177.3 137.6c-9.8 12.6-19.6 25.3-29.4 37.9C407.9 353.9 204.5 195.9 1 38C10.8 25.3 20.6 12.7 30.4 .1c60.3 46.8 120.7 93.7 181 140.5C258.3 93.7 305.1 46.9 352 0c18.7 18.7 37.3 37.3 56 56zM288 176l-13.5 13.5c40.3 31.3 80.7 62.7 121 94C359.7 247.7 323.8 211.8 288 176zm-9.4 166.7c5.8 5.7 11.6 11.5 17.4 17.3c-50.7 50.7-101.3 101.3-152 152c-26.7-26.7-53.3-53.3-80-80c50.7-50.7 101.3-101.3 152-152c5.8 5.8 11.6 11.6 17.4 17.4c3.3-3.3 6.5-6.5 9.8-9.8c16.9 13.3 33.8 26.6 50.6 39.9c-5.1 5.1-10.1 10.1-15.2 15.2z"},Hs={key:1,d:"M344 56L320 80 432 192l24-24 56 56L368 368l-56-56 24-24L224 176l-24 24-56-56L288 0l56 56zM214.6 342.6L232 360 80 512 0 432 152 280l17.4 17.4L234.7 232 280 277.3l-65.4 65.4z"},Ws=Y({__name:"GavelIcon",props:{slashed:{type:Boolean}},setup(a){return(t,e)=>(l(),c("svg",Fs,[t.slashed?(l(),c("path",Vs)):(l(),c("path",Hs))]))}}),Ys={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 640 512",width:"1em",height:"1em",fill:"currentColor"},zs={key:0,d:"M496.8 363l124.1 96.3 19 14.7-29.4 37.9-19-14.7L19 52.7 0 38 29.4 .1l19 14.7 77.8 60.4L308.4 4.5 320 0l11.6 4.5L539.1 85l19.2 7.4 1.2 20.5c2.9 50-4.9 126.3-37.3 200.9c-7.2 16.5-15.6 32.9-25.3 49zM170.4 109.5L458.6 333.3c7.4-12.6 13.9-25.5 19.5-38.5C505 232.9 512.9 169.5 512 126L320 51.5l-149.6 58zm-8.5 185.2c28.2 64.9 77 127.7 158.1 164.8c30-13.7 55.6-31 77.3-50.5l38.2 30.1c-28.1 26.5-62 49.7-102.8 67.3L320 512l-12.7-5.5c-98.4-42.6-156.7-117.3-189.4-192.6c-23.5-54.1-34.1-109-37-154.2l53.3 42c5.2 29.5 13.9 61.5 27.7 93z"},qs={key:1,d:"M267.6 4.5L256 0 244.4 4.5 36.9 85 17.8 92.5 16.6 113c-2.9 49.9 4.9 126.3 37.3 200.9c32.7 75.3 91 150 189.4 192.6L256 512l12.7-5.5c98.4-42.6 156.7-117.3 189.4-192.6c32.4-74.7 40.2-151 37.3-200.9l-1.2-20.5L475.1 85 267.6 4.5zM256 68.7l0 0L432 137c-.5 40.9-8.8 96.8-32.6 151.5c-26.2 60.3-70.6 118-143.5 153.5V68.7z"},js=Y({__name:"ShieldIcon",props:{slashed:{type:Boolean}},setup(a){return(t,e)=>(l(),c("svg",Ys,[t.slashed?(l(),c("path",zs)):(l(),c("path",qs))]))}}),Gs={},Qs={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 448 512",fill:"currentColor",width:"1em",height:"1em"},Xs=y("path",{d:"M448 32H0V480H448V32zM248 128v24V264v24H200V264 152 128h48zM200 320h48v48H200V320z"},null,-1),Ks=[Xs];function Js(a,t){return l(),c("svg",Qs,Ks)}const Zs=O(Gs,[["render",Js]]),eo={class:"seventv-user-card-mod"},to=["is-banned"],ao={class:"seventv-user-card-mod-side seventv-user-card-mod-warn"},no={class:"seventv-user-card-mod-timeout-options"},ro=["onClick"],so=["is-mod"],oo=Y({__name:"UserCardMod",props:{target:{},ban:{},isModerator:{type:Boolean}},emits:["victim-banned","victim-unbanned","victim-modded","victim-unmodded"],setup(a,{emit:t}){const e=a,r=t,{t:n}=De(),s=ue(),i=qe(s,e.target.username),f=Se(s);async function m(u){var g,o,$;const v=await i.banUserFromChat(u).catch(()=>{});!v||(g=v.errors)!=null&&g.length||!((o=v.data)!=null&&o.banUserFromChatRoom.ban)||r("victim-banned",($=v.data)==null?void 0:$.banUserFromChatRoom.ban)}async function h(){var v;const u=await i.unbanUserFromChat().catch(()=>{});!u||(v=u.errors)!=null&&v.length||r("victim-unbanned")}async function b(u){var g;const v=await i.setUserModerator(e.target.id,u).catch(()=>{});!v||(g=v.errors)!=null&&g.length||r(u?"victim-unmodded":"victim-modded")}const w=["1s","30s","1m","10m","30m","1h","4h","12h","1d","7d","14d"];return(u,v)=>{const g=pe("tooltip");return l(),c("div",eo,[y("div",{class:"seventv-user-card-mod-side seventv-user-card-mod-ban","is-banned":u.ban?"1":"0"},[X(x(Ws,{slashed:!!u.ban,onClick:v[0]||(v[0]=o=>u.ban?h():m(""))},null,8,["slashed"]),[[g,u.ban?M(n)("user_card.unban_button"):M(n)("user_card.ban_button")]])],8,to),y("div",ao,[X(x(Zs,{onClick:v[1]||(v[1]=o=>M(f).openViewerWarnPopover(u.target.id,u.target.username,0))},null,512),[[g,M(n)("user_card.warn_button")]])]),X(y("div",no,[(l(),c(z,null,se(w,o=>X(y("button",{key:o,onClick:$=>m(o)},[Z(B(o),1)],8,ro),[[g,M(n)("user_card.timeout_button",{duration:o})]])),64))],512),[[Bt,!u.ban]]),M(s).actor.roles.has("BROADCASTER")?(l(),c("div",{key:0,class:"seventv-user-card-mod-side seventv-user-card-mod-moderator","is-mod":u.isModerator?"1":"0"},[X(x(js,{slashed:u.isModerator,onClick:v[2]||(v[2]=o=>b(!!u.isModerator))},null,8,["slashed"]),[[g,u.isModerator?M(n)("user_card.unmod_button"):M(n)("user_card.mod_button")]])],8,so)):U("",!0)])}}}),io=O(oo,[["__scopeId","data-v-bb759d6b"]]),lo={class:"seventv-user-card-tabs"},uo=["selected","onClick"],co=Y({__name:"UserCardTabs",props:{activeTab:{},messageCount:{},warningCount:{},timeoutCount:{},banCount:{},commentCount:{}},emits:["switch"],setup(a,{emit:t}){const e=a,r=t,n=te(()=>[{id:"messages",label:"Messages",count:e.messageCount,maxCount:1e3},{id:"warnings",label:"Warnings",count:e.warningCount,maxCount:99},{id:"timeouts",label:"Timeouts",count:e.timeoutCount,maxCount:99},{id:"bans",label:"Bans",count:e.banCount,maxCount:99},{id:"comments",label:"Comments",count:e.commentCount,maxCount:10}]);function s(i,f){return i>=f?f.toString()+"+":i.toString()}return(i,f)=>(l(),c("div",lo,[(l(!0),c(z,null,se(n.value,m=>(l(),c("button",{key:m.label,selected:i.activeTab===m.id,onClick:h=>r("switch",m.id)},[Z(B(s(m.count,m.maxCount))+" ",1),y("p",null,B(m.label),1)],8,uo))),128))]))}}),mo=O(co,[["__scopeId","data-v-52560988"]]),ho={class:"seventv-basic-system-message"},go=Y({__name:"BasicSystemMessage",props:{text:{}},setup(a){return(t,e)=>(l(),c("span",ho,B(t.text),1))}}),vo=O(go,[["__scopeId","data-v-0218c5a7"]]);function Te(a){"@babel/helpers - typeof";return Te=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(t){return typeof t}:function(t){return t&&typeof Symbol=="function"&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},Te(a)}function fo(a){return G(1,arguments),a instanceof Date||Te(a)==="object"&&Object.prototype.toString.call(a)==="[object Date]"}function ae(a){G(1,arguments);var t=Object.prototype.toString.call(a);return a instanceof Date||Te(a)==="object"&&t==="[object Date]"?new Date(a.getTime()):typeof a=="number"||t==="[object Number]"?new Date(a):((typeof a=="string"||t==="[object String]")&&typeof console<"u"&&(console.warn("Starting with v2.0.0-beta.1 date-fns doesn't accept strings as date arguments. Please use `parseISO` to parse strings. See: https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#string-arguments"),console.warn(new Error().stack)),new Date(NaN))}function po(a){if(G(1,arguments),!fo(a)&&typeof a!="number")return!1;var t=ae(a);return!isNaN(Number(t))}function me(a){if(a===null||a===!0||a===!1)return NaN;var t=Number(a);return isNaN(t)?t:t<0?Math.ceil(t):Math.floor(t)}function yo(a,t){G(2,arguments);var e=ae(a).getTime(),r=me(t);return new Date(e+r)}function _o(a,t){G(2,arguments);var e=me(t);return yo(a,-e)}var bo=864e5;function wo(a){G(1,arguments);var t=ae(a),e=t.getTime();t.setUTCMonth(0,1),t.setUTCHours(0,0,0,0);var r=t.getTime(),n=e-r;return Math.floor(n/bo)+1}function ke(a){G(1,arguments);var t=1,e=ae(a),r=e.getUTCDay(),n=(r<t?7:0)+r-t;return e.setUTCDate(e.getUTCDate()-n),e.setUTCHours(0,0,0,0),e}function Ut(a){G(1,arguments);var t=ae(a),e=t.getUTCFullYear(),r=new Date(0);r.setUTCFullYear(e+1,0,4),r.setUTCHours(0,0,0,0);var n=ke(r),s=new Date(0);s.setUTCFullYear(e,0,4),s.setUTCHours(0,0,0,0);var i=ke(s);return t.getTime()>=n.getTime()?e+1:t.getTime()>=i.getTime()?e:e-1}function Co(a){G(1,arguments);var t=Ut(a),e=new Date(0);e.setUTCFullYear(t,0,4),e.setUTCHours(0,0,0,0);var r=ke(e);return r}var Mo=6048e5;function $o(a){G(1,arguments);var t=ae(a),e=ke(t).getTime()-Co(t).getTime();return Math.round(e/Mo)+1}var To={};function Oe(){return To}function Ue(a,t){var e,r,n,s,i,f,m,h;G(1,arguments);var b=Oe(),w=me((e=(r=(n=(s=t==null?void 0:t.weekStartsOn)!==null&&s!==void 0?s:t==null||(i=t.locale)===null||i===void 0||(f=i.options)===null||f===void 0?void 0:f.weekStartsOn)!==null&&n!==void 0?n:b.weekStartsOn)!==null&&r!==void 0?r:(m=b.locale)===null||m===void 0||(h=m.options)===null||h===void 0?void 0:h.weekStartsOn)!==null&&e!==void 0?e:0);if(!(w>=0&&w<=6))throw new RangeError("weekStartsOn must be between 0 and 6 inclusively");var u=ae(a),v=u.getUTCDay(),g=(v<w?7:0)+v-w;return u.setUTCDate(u.getUTCDate()-g),u.setUTCHours(0,0,0,0),u}function Dt(a,t){var e,r,n,s,i,f,m,h;G(1,arguments);var b=ae(a),w=b.getUTCFullYear(),u=Oe(),v=me((e=(r=(n=(s=t==null?void 0:t.firstWeekContainsDate)!==null&&s!==void 0?s:t==null||(i=t.locale)===null||i===void 0||(f=i.options)===null||f===void 0?void 0:f.firstWeekContainsDate)!==null&&n!==void 0?n:u.firstWeekContainsDate)!==null&&r!==void 0?r:(m=u.locale)===null||m===void 0||(h=m.options)===null||h===void 0?void 0:h.firstWeekContainsDate)!==null&&e!==void 0?e:1);if(!(v>=1&&v<=7))throw new RangeError("firstWeekContainsDate must be between 1 and 7 inclusively");var g=new Date(0);g.setUTCFullYear(w+1,0,v),g.setUTCHours(0,0,0,0);var o=Ue(g,t),$=new Date(0);$.setUTCFullYear(w,0,v),$.setUTCHours(0,0,0,0);var P=Ue($,t);return b.getTime()>=o.getTime()?w+1:b.getTime()>=P.getTime()?w:w-1}function ko(a,t){var e,r,n,s,i,f,m,h;G(1,arguments);var b=Oe(),w=me((e=(r=(n=(s=t==null?void 0:t.firstWeekContainsDate)!==null&&s!==void 0?s:t==null||(i=t.locale)===null||i===void 0||(f=i.options)===null||f===void 0?void 0:f.firstWeekContainsDate)!==null&&n!==void 0?n:b.firstWeekContainsDate)!==null&&r!==void 0?r:(m=b.locale)===null||m===void 0||(h=m.options)===null||h===void 0?void 0:h.firstWeekContainsDate)!==null&&e!==void 0?e:1),u=Dt(a,t),v=new Date(0);v.setUTCFullYear(u,0,w),v.setUTCHours(0,0,0,0);var g=Ue(v,t);return g}var Uo=6048e5;function Do(a,t){G(1,arguments);var e=ae(a),r=Ue(e,t).getTime()-ko(e,t).getTime();return Math.round(r/Uo)+1}function A(a,t){for(var e=a<0?"-":"",r=Math.abs(a).toString();r.length<t;)r="0"+r;return e+r}var Lo={y:function(t,e){var r=t.getUTCFullYear(),n=r>0?r:1-r;return A(e==="yy"?n%100:n,e.length)},M:function(t,e){var r=t.getUTCMonth();return e==="M"?String(r+1):A(r+1,2)},d:function(t,e){return A(t.getUTCDate(),e.length)},a:function(t,e){var r=t.getUTCHours()/12>=1?"pm":"am";switch(e){case"a":case"aa":return r.toUpperCase();case"aaa":return r;case"aaaaa":return r[0];case"aaaa":default:return r==="am"?"a.m.":"p.m."}},h:function(t,e){return A(t.getUTCHours()%12||12,e.length)},H:function(t,e){return A(t.getUTCHours(),e.length)},m:function(t,e){return A(t.getUTCMinutes(),e.length)},s:function(t,e){return A(t.getUTCSeconds(),e.length)},S:function(t,e){var r=e.length,n=t.getUTCMilliseconds(),s=Math.floor(n*Math.pow(10,r-3));return A(s,e.length)}};const ie=Lo;var ge={am:"am",pm:"pm",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"},Io={G:function(t,e,r){var n=t.getUTCFullYear()>0?1:0;switch(e){case"G":case"GG":case"GGG":return r.era(n,{width:"abbreviated"});case"GGGGG":return r.era(n,{width:"narrow"});case"GGGG":default:return r.era(n,{width:"wide"})}},y:function(t,e,r){if(e==="yo"){var n=t.getUTCFullYear(),s=n>0?n:1-n;return r.ordinalNumber(s,{unit:"year"})}return ie.y(t,e)},Y:function(t,e,r,n){var s=Dt(t,n),i=s>0?s:1-s;if(e==="YY"){var f=i%100;return A(f,2)}return e==="Yo"?r.ordinalNumber(i,{unit:"year"}):A(i,e.length)},R:function(t,e){var r=Ut(t);return A(r,e.length)},u:function(t,e){var r=t.getUTCFullYear();return A(r,e.length)},Q:function(t,e,r){var n=Math.ceil((t.getUTCMonth()+1)/3);switch(e){case"Q":return String(n);case"QQ":return A(n,2);case"Qo":return r.ordinalNumber(n,{unit:"quarter"});case"QQQ":return r.quarter(n,{width:"abbreviated",context:"formatting"});case"QQQQQ":return r.quarter(n,{width:"narrow",context:"formatting"});case"QQQQ":default:return r.quarter(n,{width:"wide",context:"formatting"})}},q:function(t,e,r){var n=Math.ceil((t.getUTCMonth()+1)/3);switch(e){case"q":return String(n);case"qq":return A(n,2);case"qo":return r.ordinalNumber(n,{unit:"quarter"});case"qqq":return r.quarter(n,{width:"abbreviated",context:"standalone"});case"qqqqq":return r.quarter(n,{width:"narrow",context:"standalone"});case"qqqq":default:return r.quarter(n,{width:"wide",context:"standalone"})}},M:function(t,e,r){var n=t.getUTCMonth();switch(e){case"M":case"MM":return ie.M(t,e);case"Mo":return r.ordinalNumber(n+1,{unit:"month"});case"MMM":return r.month(n,{width:"abbreviated",context:"formatting"});case"MMMMM":return r.month(n,{width:"narrow",context:"formatting"});case"MMMM":default:return r.month(n,{width:"wide",context:"formatting"})}},L:function(t,e,r){var n=t.getUTCMonth();switch(e){case"L":return String(n+1);case"LL":return A(n+1,2);case"Lo":return r.ordinalNumber(n+1,{unit:"month"});case"LLL":return r.month(n,{width:"abbreviated",context:"standalone"});case"LLLLL":return r.month(n,{width:"narrow",context:"standalone"});case"LLLL":default:return r.month(n,{width:"wide",context:"standalone"})}},w:function(t,e,r,n){var s=Do(t,n);return e==="wo"?r.ordinalNumber(s,{unit:"week"}):A(s,e.length)},I:function(t,e,r){var n=$o(t);return e==="Io"?r.ordinalNumber(n,{unit:"week"}):A(n,e.length)},d:function(t,e,r){return e==="do"?r.ordinalNumber(t.getUTCDate(),{unit:"date"}):ie.d(t,e)},D:function(t,e,r){var n=wo(t);return e==="Do"?r.ordinalNumber(n,{unit:"dayOfYear"}):A(n,e.length)},E:function(t,e,r){var n=t.getUTCDay();switch(e){case"E":case"EE":case"EEE":return r.day(n,{width:"abbreviated",context:"formatting"});case"EEEEE":return r.day(n,{width:"narrow",context:"formatting"});case"EEEEEE":return r.day(n,{width:"short",context:"formatting"});case"EEEE":default:return r.day(n,{width:"wide",context:"formatting"})}},e:function(t,e,r,n){var s=t.getUTCDay(),i=(s-n.weekStartsOn+8)%7||7;switch(e){case"e":return String(i);case"ee":return A(i,2);case"eo":return r.ordinalNumber(i,{unit:"day"});case"eee":return r.day(s,{width:"abbreviated",context:"formatting"});case"eeeee":return r.day(s,{width:"narrow",context:"formatting"});case"eeeeee":return r.day(s,{width:"short",context:"formatting"});case"eeee":default:return r.day(s,{width:"wide",context:"formatting"})}},c:function(t,e,r,n){var s=t.getUTCDay(),i=(s-n.weekStartsOn+8)%7||7;switch(e){case"c":return String(i);case"cc":return A(i,e.length);case"co":return r.ordinalNumber(i,{unit:"day"});case"ccc":return r.day(s,{width:"abbreviated",context:"standalone"});case"ccccc":return r.day(s,{width:"narrow",context:"standalone"});case"cccccc":return r.day(s,{width:"short",context:"standalone"});case"cccc":default:return r.day(s,{width:"wide",context:"standalone"})}},i:function(t,e,r){var n=t.getUTCDay(),s=n===0?7:n;switch(e){case"i":return String(s);case"ii":return A(s,e.length);case"io":return r.ordinalNumber(s,{unit:"day"});case"iii":return r.day(n,{width:"abbreviated",context:"formatting"});case"iiiii":return r.day(n,{width:"narrow",context:"formatting"});case"iiiiii":return r.day(n,{width:"short",context:"formatting"});case"iiii":default:return r.day(n,{width:"wide",context:"formatting"})}},a:function(t,e,r){var n=t.getUTCHours(),s=n/12>=1?"pm":"am";switch(e){case"a":case"aa":return r.dayPeriod(s,{width:"abbreviated",context:"formatting"});case"aaa":return r.dayPeriod(s,{width:"abbreviated",context:"formatting"}).toLowerCase();case"aaaaa":return r.dayPeriod(s,{width:"narrow",context:"formatting"});case"aaaa":default:return r.dayPeriod(s,{width:"wide",context:"formatting"})}},b:function(t,e,r){var n=t.getUTCHours(),s;switch(n===12?s=ge.noon:n===0?s=ge.midnight:s=n/12>=1?"pm":"am",e){case"b":case"bb":return r.dayPeriod(s,{width:"abbreviated",context:"formatting"});case"bbb":return r.dayPeriod(s,{width:"abbreviated",context:"formatting"}).toLowerCase();case"bbbbb":return r.dayPeriod(s,{width:"narrow",context:"formatting"});case"bbbb":default:return r.dayPeriod(s,{width:"wide",context:"formatting"})}},B:function(t,e,r){var n=t.getUTCHours(),s;switch(n>=17?s=ge.evening:n>=12?s=ge.afternoon:n>=4?s=ge.morning:s=ge.night,e){case"B":case"BB":case"BBB":return r.dayPeriod(s,{width:"abbreviated",context:"formatting"});case"BBBBB":return r.dayPeriod(s,{width:"narrow",context:"formatting"});case"BBBB":default:return r.dayPeriod(s,{width:"wide",context:"formatting"})}},h:function(t,e,r){if(e==="ho"){var n=t.getUTCHours()%12;return n===0&&(n=12),r.ordinalNumber(n,{unit:"hour"})}return ie.h(t,e)},H:function(t,e,r){return e==="Ho"?r.ordinalNumber(t.getUTCHours(),{unit:"hour"}):ie.H(t,e)},K:function(t,e,r){var n=t.getUTCHours()%12;return e==="Ko"?r.ordinalNumber(n,{unit:"hour"}):A(n,e.length)},k:function(t,e,r){var n=t.getUTCHours();return n===0&&(n=24),e==="ko"?r.ordinalNumber(n,{unit:"hour"}):A(n,e.length)},m:function(t,e,r){return e==="mo"?r.ordinalNumber(t.getUTCMinutes(),{unit:"minute"}):ie.m(t,e)},s:function(t,e,r){return e==="so"?r.ordinalNumber(t.getUTCSeconds(),{unit:"second"}):ie.s(t,e)},S:function(t,e){return ie.S(t,e)},X:function(t,e,r,n){var s=n._originalDate||t,i=s.getTimezoneOffset();if(i===0)return"Z";switch(e){case"X":return ut(i);case"XXXX":case"XX":return de(i);case"XXXXX":case"XXX":default:return de(i,":")}},x:function(t,e,r,n){var s=n._originalDate||t,i=s.getTimezoneOffset();switch(e){case"x":return ut(i);case"xxxx":case"xx":return de(i);case"xxxxx":case"xxx":default:return de(i,":")}},O:function(t,e,r,n){var s=n._originalDate||t,i=s.getTimezoneOffset();switch(e){case"O":case"OO":case"OOO":return"GMT"+lt(i,":");case"OOOO":default:return"GMT"+de(i,":")}},z:function(t,e,r,n){var s=n._originalDate||t,i=s.getTimezoneOffset();switch(e){case"z":case"zz":case"zzz":return"GMT"+lt(i,":");case"zzzz":default:return"GMT"+de(i,":")}},t:function(t,e,r,n){var s=n._originalDate||t,i=Math.floor(s.getTime()/1e3);return A(i,e.length)},T:function(t,e,r,n){var s=n._originalDate||t,i=s.getTime();return A(i,e.length)}};function lt(a,t){var e=a>0?"-":"+",r=Math.abs(a),n=Math.floor(r/60),s=r%60;if(s===0)return e+String(n);var i=t||"";return e+String(n)+i+A(s,2)}function ut(a,t){if(a%60===0){var e=a>0?"-":"+";return e+A(Math.abs(a)/60,2)}return de(a,t)}function de(a,t){var e=t||"",r=a>0?"-":"+",n=Math.abs(a),s=A(Math.floor(n/60),2),i=A(n%60,2);return r+s+e+i}const So=Io;var dt=function(t,e){switch(t){case"P":return e.date({width:"short"});case"PP":return e.date({width:"medium"});case"PPP":return e.date({width:"long"});case"PPPP":default:return e.date({width:"full"})}},Lt=function(t,e){switch(t){case"p":return e.time({width:"short"});case"pp":return e.time({width:"medium"});case"ppp":return e.time({width:"long"});case"pppp":default:return e.time({width:"full"})}},Oo=function(t,e){var r=t.match(/(P+)(p+)?/)||[],n=r[1],s=r[2];if(!s)return dt(t,e);var i;switch(n){case"P":i=e.dateTime({width:"short"});break;case"PP":i=e.dateTime({width:"medium"});break;case"PPP":i=e.dateTime({width:"long"});break;case"PPPP":default:i=e.dateTime({width:"full"});break}return i.replace("{{date}}",dt(n,e)).replace("{{time}}",Lt(s,e))},Po={p:Lt,P:Oo};const xo=Po;function Eo(a){var t=new Date(Date.UTC(a.getFullYear(),a.getMonth(),a.getDate(),a.getHours(),a.getMinutes(),a.getSeconds(),a.getMilliseconds()));return t.setUTCFullYear(a.getFullYear()),a.getTime()-t.getTime()}var Ao=["D","DD"],Ro=["YY","YYYY"];function Bo(a){return Ao.indexOf(a)!==-1}function No(a){return Ro.indexOf(a)!==-1}function ct(a,t,e){if(a==="YYYY")throw new RangeError("Use `yyyy` instead of `YYYY` (in `".concat(t,"`) for formatting years to the input `").concat(e,"`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md"));if(a==="YY")throw new RangeError("Use `yy` instead of `YY` (in `".concat(t,"`) for formatting years to the input `").concat(e,"`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md"));if(a==="D")throw new RangeError("Use `d` instead of `D` (in `".concat(t,"`) for formatting days of the month to the input `").concat(e,"`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md"));if(a==="DD")throw new RangeError("Use `dd` instead of `DD` (in `".concat(t,"`) for formatting days of the month to the input `").concat(e,"`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md"))}var Fo={lessThanXSeconds:{one:"less than a second",other:"less than {{count}} seconds"},xSeconds:{one:"1 second",other:"{{count}} seconds"},halfAMinute:"half a minute",lessThanXMinutes:{one:"less than a minute",other:"less than {{count}} minutes"},xMinutes:{one:"1 minute",other:"{{count}} minutes"},aboutXHours:{one:"about 1 hour",other:"about {{count}} hours"},xHours:{one:"1 hour",other:"{{count}} hours"},xDays:{one:"1 day",other:"{{count}} days"},aboutXWeeks:{one:"about 1 week",other:"about {{count}} weeks"},xWeeks:{one:"1 week",other:"{{count}} weeks"},aboutXMonths:{one:"about 1 month",other:"about {{count}} months"},xMonths:{one:"1 month",other:"{{count}} months"},aboutXYears:{one:"about 1 year",other:"about {{count}} years"},xYears:{one:"1 year",other:"{{count}} years"},overXYears:{one:"over 1 year",other:"over {{count}} years"},almostXYears:{one:"almost 1 year",other:"almost {{count}} years"}},Vo=function(t,e,r){var n,s=Fo[t];return typeof s=="string"?n=s:e===1?n=s.one:n=s.other.replace("{{count}}",e.toString()),r!=null&&r.addSuffix?r.comparison&&r.comparison>0?"in "+n:n+" ago":n};const Ho=Vo;function Ae(a){return function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},e=t.width?String(t.width):a.defaultWidth,r=a.formats[e]||a.formats[a.defaultWidth];return r}}var Wo={full:"EEEE, MMMM do, y",long:"MMMM do, y",medium:"MMM d, y",short:"MM/dd/yyyy"},Yo={full:"h:mm:ss a zzzz",long:"h:mm:ss a z",medium:"h:mm:ss a",short:"h:mm a"},zo={full:"{{date}} 'at' {{time}}",long:"{{date}} 'at' {{time}}",medium:"{{date}}, {{time}}",short:"{{date}}, {{time}}"},qo={date:Ae({formats:Wo,defaultWidth:"full"}),time:Ae({formats:Yo,defaultWidth:"full"}),dateTime:Ae({formats:zo,defaultWidth:"full"})};const jo=qo;var Go={lastWeek:"'last' eeee 'at' p",yesterday:"'yesterday at' p",today:"'today at' p",tomorrow:"'tomorrow at' p",nextWeek:"eeee 'at' p",other:"P"},Qo=function(t,e,r,n){return Go[t]};const Xo=Qo;function ye(a){return function(t,e){var r=e!=null&&e.context?String(e.context):"standalone",n;if(r==="formatting"&&a.formattingValues){var s=a.defaultFormattingWidth||a.defaultWidth,i=e!=null&&e.width?String(e.width):s;n=a.formattingValues[i]||a.formattingValues[s]}else{var f=a.defaultWidth,m=e!=null&&e.width?String(e.width):a.defaultWidth;n=a.values[m]||a.values[f]}var h=a.argumentCallback?a.argumentCallback(t):t;return n[h]}}var Ko={narrow:["B","A"],abbreviated:["BC","AD"],wide:["Before Christ","Anno Domini"]},Jo={narrow:["1","2","3","4"],abbreviated:["Q1","Q2","Q3","Q4"],wide:["1st quarter","2nd quarter","3rd quarter","4th quarter"]},Zo={narrow:["J","F","M","A","M","J","J","A","S","O","N","D"],abbreviated:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],wide:["January","February","March","April","May","June","July","August","September","October","November","December"]},ei={narrow:["S","M","T","W","T","F","S"],short:["Su","Mo","Tu","We","Th","Fr","Sa"],abbreviated:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],wide:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]},ti={narrow:{am:"a",pm:"p",midnight:"mi",noon:"n",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"},abbreviated:{am:"AM",pm:"PM",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"},wide:{am:"a.m.",pm:"p.m.",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"}},ai={narrow:{am:"a",pm:"p",midnight:"mi",noon:"n",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"},abbreviated:{am:"AM",pm:"PM",midnight:"midnight",noon:"noon",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"},wide:{am:"a.m.",pm:"p.m.",midnight:"midnight",noon:"noon",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"}},ni=function(t,e){var r=Number(t),n=r%100;if(n>20||n<10)switch(n%10){case 1:return r+"st";case 2:return r+"nd";case 3:return r+"rd"}return r+"th"},ri={ordinalNumber:ni,era:ye({values:Ko,defaultWidth:"wide"}),quarter:ye({values:Jo,defaultWidth:"wide",argumentCallback:function(t){return t-1}}),month:ye({values:Zo,defaultWidth:"wide"}),day:ye({values:ei,defaultWidth:"wide"}),dayPeriod:ye({values:ti,defaultWidth:"wide",formattingValues:ai,defaultFormattingWidth:"wide"})};const si=ri;function _e(a){return function(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=e.width,n=r&&a.matchPatterns[r]||a.matchPatterns[a.defaultMatchWidth],s=t.match(n);if(!s)return null;var i=s[0],f=r&&a.parsePatterns[r]||a.parsePatterns[a.defaultParseWidth],m=Array.isArray(f)?ii(f,function(w){return w.test(i)}):oi(f,function(w){return w.test(i)}),h;h=a.valueCallback?a.valueCallback(m):m,h=e.valueCallback?e.valueCallback(h):h;var b=t.slice(i.length);return{value:h,rest:b}}}function oi(a,t){for(var e in a)if(a.hasOwnProperty(e)&&t(a[e]))return e}function ii(a,t){for(var e=0;e<a.length;e++)if(t(a[e]))return e}function li(a){return function(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=t.match(a.matchPattern);if(!r)return null;var n=r[0],s=t.match(a.parsePattern);if(!s)return null;var i=a.valueCallback?a.valueCallback(s[0]):s[0];i=e.valueCallback?e.valueCallback(i):i;var f=t.slice(n.length);return{value:i,rest:f}}}var ui=/^(\d+)(th|st|nd|rd)?/i,di=/\d+/i,ci={narrow:/^(b|a)/i,abbreviated:/^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,wide:/^(before christ|before common era|anno domini|common era)/i},mi={any:[/^b/i,/^(a|c)/i]},hi={narrow:/^[1234]/i,abbreviated:/^q[1234]/i,wide:/^[1234](th|st|nd|rd)? quarter/i},gi={any:[/1/i,/2/i,/3/i,/4/i]},vi={narrow:/^[jfmasond]/i,abbreviated:/^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,wide:/^(january|february|march|april|may|june|july|august|september|october|november|december)/i},fi={narrow:[/^j/i,/^f/i,/^m/i,/^a/i,/^m/i,/^j/i,/^j/i,/^a/i,/^s/i,/^o/i,/^n/i,/^d/i],any:[/^ja/i,/^f/i,/^mar/i,/^ap/i,/^may/i,/^jun/i,/^jul/i,/^au/i,/^s/i,/^o/i,/^n/i,/^d/i]},pi={narrow:/^[smtwf]/i,short:/^(su|mo|tu|we|th|fr|sa)/i,abbreviated:/^(sun|mon|tue|wed|thu|fri|sat)/i,wide:/^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i},yi={narrow:[/^s/i,/^m/i,/^t/i,/^w/i,/^t/i,/^f/i,/^s/i],any:[/^su/i,/^m/i,/^tu/i,/^w/i,/^th/i,/^f/i,/^sa/i]},_i={narrow:/^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,any:/^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i},bi={any:{am:/^a/i,pm:/^p/i,midnight:/^mi/i,noon:/^no/i,morning:/morning/i,afternoon:/afternoon/i,evening:/evening/i,night:/night/i}},wi={ordinalNumber:li({matchPattern:ui,parsePattern:di,valueCallback:function(t){return parseInt(t,10)}}),era:_e({matchPatterns:ci,defaultMatchWidth:"wide",parsePatterns:mi,defaultParseWidth:"any"}),quarter:_e({matchPatterns:hi,defaultMatchWidth:"wide",parsePatterns:gi,defaultParseWidth:"any",valueCallback:function(t){return t+1}}),month:_e({matchPatterns:vi,defaultMatchWidth:"wide",parsePatterns:fi,defaultParseWidth:"any"}),day:_e({matchPatterns:pi,defaultMatchWidth:"wide",parsePatterns:yi,defaultParseWidth:"any"}),dayPeriod:_e({matchPatterns:_i,defaultMatchWidth:"any",parsePatterns:bi,defaultParseWidth:"any"})};const Ci=wi;var Mi={code:"en-US",formatDistance:Ho,formatLong:jo,formatRelative:Xo,localize:si,match:Ci,options:{weekStartsOn:0,firstWeekContainsDate:1}};const $i=Mi;var Ti=/[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g,ki=/P+p+|P+|p+|''|'(''|[^'])+('|$)|./g,Ui=/^'([^]*?)'?$/,Di=/''/g,Li=/[a-zA-Z]/;function Ii(a,t,e){var r,n,s,i,f,m,h,b,w,u,v,g,o,$,P,E,q,N;G(2,arguments);var _=String(t),C=Oe(),p=(r=(n=e==null?void 0:e.locale)!==null&&n!==void 0?n:C.locale)!==null&&r!==void 0?r:$i,D=me((s=(i=(f=(m=e==null?void 0:e.firstWeekContainsDate)!==null&&m!==void 0?m:e==null||(h=e.locale)===null||h===void 0||(b=h.options)===null||b===void 0?void 0:b.firstWeekContainsDate)!==null&&f!==void 0?f:C.firstWeekContainsDate)!==null&&i!==void 0?i:(w=C.locale)===null||w===void 0||(u=w.options)===null||u===void 0?void 0:u.firstWeekContainsDate)!==null&&s!==void 0?s:1);if(!(D>=1&&D<=7))throw new RangeError("firstWeekContainsDate must be between 1 and 7 inclusively");var R=me((v=(g=(o=($=e==null?void 0:e.weekStartsOn)!==null&&$!==void 0?$:e==null||(P=e.locale)===null||P===void 0||(E=P.options)===null||E===void 0?void 0:E.weekStartsOn)!==null&&o!==void 0?o:C.weekStartsOn)!==null&&g!==void 0?g:(q=C.locale)===null||q===void 0||(N=q.options)===null||N===void 0?void 0:N.weekStartsOn)!==null&&v!==void 0?v:0);if(!(R>=0&&R<=6))throw new RangeError("weekStartsOn must be between 0 and 6 inclusively");if(!p.localize)throw new RangeError("locale must contain localize property");if(!p.formatLong)throw new RangeError("locale must contain formatLong property");var F=ae(a);if(!po(F))throw new RangeError("Invalid time value");var j=Eo(F),L=_o(F,j),d={firstWeekContainsDate:D,weekStartsOn:R,locale:p,_originalDate:F},T=_.match(ki).map(function(k){var S=k[0];if(S==="p"||S==="P"){var H=xo[S];return H(k,p.formatLong)}return k}).join("").match(Ti).map(function(k){if(k==="''")return"'";var S=k[0];if(S==="'")return Si(k);var H=So[S];if(H)return!(e!=null&&e.useAdditionalWeekYearTokens)&&No(k)&&ct(k,t,String(a)),!(e!=null&&e.useAdditionalDayOfYearTokens)&&Bo(k)&&ct(k,t,String(a)),H(L,k,p.localize,d);if(S.match(Li))throw new RangeError("Format string contains an unescaped latin alphabet character `"+S+"`");return k}).join("");return T}function Si(a){var t=a.match(Ui);return t?t[1].replace(Di,"'"):a}const Oi=Ge(Ii,2),Pi={class:"seventv-user-card-container"},xi={class:"seventv-user-card-header"},Ei={class:"seventv-user-card-menuactions"},Ai={class:"seventv-user-card-avatar"},Ri=["src"],Bi=["src"],Ni={class:"seventv-user-card-usertag-container"},Fi=["href"],Vi=["data-seventv-paint-id"],Hi={class:"seventv-user-card-badges"},Wi={class:"seventv-user-card-interactive"},Yi={class:"seventv-user-card-metrics"},zi={key:0},qi={key:1},ji={key:2},Gi={key:3},Qi=["show-tabs"],Xi="https://twitch.tv",Ki=Y({__name:"UserCard",props:{target:{}},emits:["close","mount-handle"],setup(a,{emit:t}){const e=a,r=t,n=ue(),s=aa(n),{identity:i}=qt(jt()),f=Ye(e.target.id),m=Se(n),h=Ca(n),b=Ie(),{t:w}=De(),u=I(),v=I(),g=I(null),o=ce({activeTab:"messages",canActorAccessLogs:!1,ban:null,paint:null,targetUser:{id:e.target.id,username:e.target.username,displayName:e.target.displayName,intl:e.target.intl,color:e.target.color,bannerURL:"",avatarURL:"",createdAt:"",isModerator:!1,badges:[],relationship:{followedAt:"",subscription:{isSubscribed:!1,tier:"",months:0}}},stream:{live:!1,game:"",viewCount:0},messageCursors:new WeakMap,timelines:{messages:{},warnings:{},bans:{},timeouts:{},comments:{}},count:{messages:0,warnings:0,bans:0,timeouts:0,comments:0}}),$=te(()=>{var k;if(!o.targetUser.username)return;const d=ze("avatars").value;if(!((k=d==null?void 0:d.instance)!=null&&k.avatars))return;const T=d.instance.avatars[o.targetUser.username];return T==null?void 0:T.data.user.avatar_url});function P(){return o.timelines[o.activeTab]}async function E(d){var H;if(!o.targetUser||!b.value||o.activeTab!=="messages")return[];const T=d?o.messageCursors.get(d):void 0,k=await b.value.query({query:Ta,variables:{channelID:n.id,senderID:o.targetUser.id,cursor:T}}).catch(W=>Promise.reject(W));if(!k||(H=k.errors)!=null&&H.length||!Array.isArray(k.data.logs.messages.edges))return[];const S=[];for(const W of k.data.logs.messages.edges){if(!W.node)continue;const K=Ne(W.node);S.push(K),o.messageCursors.set(K,W.cursor)}return S}async function q(){var H;if(!o.targetUser||!b.value)return;const d=await b.value.query({query:$a,variables:{channelLogin:n.username,channelID:n.id,targetID:o.targetUser.id}}).catch(W=>Promise.reject(W));if(!d||(H=d.errors)!=null&&H.length||!d.data.channelUser)return;o.count.messages=d.data.viewerCardModLogs.messages.count??0,o.count.warnings=d.data.viewerCardModLogs.warnings.count??0,o.count.bans=d.data.viewerCardModLogs.bans.count??0,o.count.timeouts=d.data.viewerCardModLogs.timeouts.count??0,o.count.comments=d.data.viewerCardModLogs.comments.edges.length??0,o.ban=d.data.banStatus;const T=d.data.viewerCardModLogs.timeouts.edges,k=d.data.viewerCardModLogs.bans.edges,S=d.data.viewerCardModLogs.warnings.edges;for(const[W,K]of[["timeouts",T],["bans",k],["warnings",S]]){const ne=[];for(const oe of K){const J=new Je(oe.node.id).setComponent(vo,{text:oe.node.localizedLabel.localizedStringFragments.map(he=>"text"in he.token?he.token.text:he.token.login).join("")});J.setTimestamp(Date.parse(oe.node.timestamp)),ne.push(J)}p(ne,W)}for(const W of d.data.viewerCardModLogs.comments.edges)N(W.node)}function N(d){const T=new Je(d.id);T.setAuthor({id:d.author.id,username:d.author.login,displayName:d.author.displayName,color:d.author.chatColor,intl:d.author.login!==d.author.displayName.toLowerCase()}),T.setTimestamp(Date.parse(d.timestamp)),T.body=d.text,p([T],"comments")}function _(){if(!u.value||!u.value.container||u.value.container.scrollTop>0)return;const T=C(new Date(Math.min(...Object.keys(o.timelines.messages).map(H=>Date.parse(H)||1/0))));if(!T)return;const k=o.timelines.messages[T];if(!k)return;const S=k[0];S&&(D(1),E(S).then(H=>{H.length&&p(H)}).catch(H=>{le.error("Failed to fetch more messages",H)}))}function C(d){return`${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`}function p(d,T="messages"){const k=o.timelines[T],S=s.find(W=>!!W.author&&W.author.id===e.target.id,!0),H=new Set(S.map(W=>W.id));for(const W of d){if(!W.timestamp)continue;const K=H.has(W.id)?"LIVE":C(new Date(W.timestamp));if(!k[K])k[K]=[];else if(k[K].find(ne=>ne.id===W.id))continue;k[K].unshift(W),k[K].sort((ne,oe)=>ne.timestamp-oe.timestamp)}}function D(d){!u.value||!u.value.container||u.value.container.scrollTo({top:d})}function R(d){!o.targetUser.username||!m.openViewerCard(d,o.targetUser.username,"")||r("close")}function F(){if(!o.targetUser.username)return;let d=!1;o.targetUser.username in h.getAllUsernameHighlights()?(h.remove(o.targetUser.username),d=!0):(h.define(o.targetUser.username,{pattern:o.targetUser.username,label:"Messages by "+o.targetUser.username,color:"#8803fc",flashTitle:!1,username:!0},!0),d=!0),d&&h.save()}function j(){return`${Xi}/${e.target.username}`}function L(d){return d?Oi("PPP")(new Date(d)):""}return ve(async()=>{if(b.value){b.value.query({query:Ma,variables:{channelID:n.id,channelIDStr:n.id,channelLogin:n.username,giftRecipientLogin:e.target.username,withStandardGifting:!1}}).then(async d=>{var T,k,S,H,W,K,ne,oe;if(d.data.channel&&(o.canActorAccessLogs=((T=d.data.channel.moderationSettings)==null?void 0:T.canAccessViewerCardModLogs)??!1),d.data.targetUser){if(o.targetUser.id=d.data.targetUser.id,o.targetUser.username=d.data.targetUser.login,o.targetUser.displayName=d.data.targetUser.displayName,o.targetUser.intl=d.data.targetUser.login!==d.data.targetUser.displayName.toLowerCase(),o.targetUser.avatarURL=d.data.targetUser.profileImageURL,o.targetUser.bannerURL=d.data.targetUser.bannerImageURL??"",o.targetUser.color=d.data.targetUser.chatColor??e.target.color,o.targetUser.relationship.followedAt=L((k=d.data.targetUser.relationship)==null?void 0:k.followedAt),o.targetUser.createdAt=L(d.data.targetUser.createdAt),o.targetUser.relationship.subscription.months=((H=(S=d.data.targetUser.relationship)==null?void 0:S.cumulativeTenure)==null?void 0:H.months)??0,(W=d.data.targetUser.relationship)!=null&&W.subscriptionBenefit&&(o.targetUser.relationship.subscription.isSubscribed=!0,o.targetUser.relationship.subscription.tier=(K=d.data.targetUser.relationship)==null?void 0:K.subscriptionBenefit.tier),d.data.targetUser.stream&&(o.stream.live=!0,o.stream.game=((ne=d.data.targetUser.stream.game)==null?void 0:ne.displayName)??"",o.stream.viewCount=d.data.targetUser.stream.viewersCount),o.targetUser.badges.length=0,o.targetUser.isModerator=d.data.targetUser.isModerator||d.data.targetUser.id===n.id,d.data.channelViewer&&((oe=d.data.channelViewer.earnedBadges)!=null&&oe.length))for(let J=0;J<d.data.channelViewer.earnedBadges.length;J++){const he=Xt(d.data.channelViewer.earnedBadges[J]);he&&(o.targetUser.badges[J]=he)}for(const J of f.badges.values())o.targetUser.badges.push(J)}o.targetUser&&(o.canActorAccessLogs||i.value&&o.targetUser.id===i.value.id)&&(p(await E().catch(J=>le.error("failed to fetch message logs",J))??[]),q().catch(J=>le.error("failed to fetch moderator data",J)))}).catch(d=>le.error("failed to query user card",d));for(const d of f.paints.values()){o.paint=d;break}}}),re(()=>[o.targetUser.bannerURL,o.targetUser.color],([d,T])=>{g.value&&(g.value.style.setProperty("--seventv-user-card-banner-url",`url(${d})`),g.value.style.setProperty("--seventv-user-card-color",T))}),ht(async()=>{v.value&&r("mount-handle",v.value),p(s.find(d=>!!d.author&&d.author.id===e.target.id,!0)),Le(()=>{!u.value||!u.value.container||D(u.value.container.scrollHeight)})}),(d,T)=>{const k=pe("tooltip");return l(),c("main",Pi,[y("div",{ref_key:"cardRef",ref:g,class:"seventv-user-card"},[y("div",xi,[y("div",{ref_key:"dragHandle",ref:v,class:"seventv-user-card-identity"},[y("div",Ei,[o.targetUser.username in M(h).getAllUsernameHighlights()?X((l(),V(Ba,{key:0,onClick:F},null,512)),[[k,M(w)("user_card.stop_highlight")]]):X((l(),V(Oa,{key:1,onClick:F},null,512)),[[k,M(w)("user_card.highlight")]]),X(x(Gt,{onClick:R},null,512),[[k,M(w)("user_card.native")]]),x(Qt,{class:"close-button",onClick:T[0]||(T[0]=S=>r("close"))})]),y("div",Ai,[$.value?(l(),c("img",{key:0,src:$.value},null,8,Ri)):o.targetUser.avatarURL?(l(),c("img",{key:1,src:o.targetUser.avatarURL},null,8,Bi)):U("",!0)]),y("div",Ni,[y("a",{href:j(),target:"_blank",class:"seventv-user-card-usertag"},[x(we,{user:o.targetUser,"hide-badges":!0,clickable:!1},null,8,["user"])],8,Fi)]),o.paint?(l(),c("span",{key:0,class:"seventv-user-card-paint seventv-painted-content seventv-paint","data-seventv-paint-id":o.paint.id},[y("p",null,B(o.paint.data.name),1)],8,Vi)):U("",!0),y("div",Hi,[(l(!0),c(z,null,se(o.targetUser.badges,S=>(l(),V(Me,{key:S.id,badge:S,alt:S.data.tooltip,type:"app"},null,8,["badge","alt"]))),128))])],512),y("div",Wi,[y("div",Yi,[o.targetUser.createdAt?(l(),c("p",zi,[x(Ya),Z(" "+B(M(w)("user_card.account_created_date",{date:o.targetUser.createdAt})),1)])):U("",!0),o.targetUser.relationship.followedAt?(l(),c("p",qi,[x(Xa),Z(" "+B(M(w)("user_card.following_since_date",{date:o.targetUser.relationship.followedAt})),1)])):U("",!0),o.targetUser.relationship.subscription.isSubscribed?(l(),c("p",ji,[x(Ze),Z(" "+B(o.targetUser.relationship.subscription.months?`${M(w)("user_card.subscription_tier",{tier:o.targetUser.relationship.subscription.tier[0]})} -
									  ${M(w)("user_card.subscription_length",{length:o.targetUser.relationship.subscription.months})}`:`${M(w)("user_card.hidden_subscription_status")}`),1)])):o.targetUser.relationship.subscription.months?(l(),c("p",Gi,[x(Ze),Z(" "+B(M(w)("user_card.previously_subscription_length",{length:o.targetUser.relationship.subscription.months})),1)])):U("",!0)]),x(en),M(n).actor.roles.has("MODERATOR")&&!o.targetUser.isModerator||M(n).actor.roles.has("BROADCASTER")?(l(),V(io,{key:0,target:o.targetUser,ban:o.ban,"is-moderator":o.targetUser.isModerator,onVictimBanned:T[1]||(T[1]=S=>o.ban=S),onVictimUnbanned:T[2]||(T[2]=S=>o.ban=null),onVictimModded:T[3]||(T[3]=S=>o.targetUser.isModerator=!0),onVictimUnmodded:T[4]||(T[4]=S=>o.targetUser.isModerator=!1)},null,8,["target","ban","is-moderator"])):U("",!0)])]),y("div",{class:"seventv-user-card-data","show-tabs":M(n).actor.roles.has("MODERATOR")},[M(n).actor.roles.has("MODERATOR")?(l(),V(mo,{key:0,"active-tab":o.activeTab,"message-count":o.count.messages,"warning-count":o.count.warnings,"ban-count":o.count.bans,"timeout-count":o.count.timeouts,"comment-count":o.count.comments,onSwitch:T[5]||(T[5]=S=>o.activeTab=S)},null,8,["active-tab","message-count","warning-count","ban-count","timeout-count","comment-count"])):U("",!0),x(Mt,{ref_key:"scroller",ref:u,onContainerScroll:_},{default:fe(()=>[x(Ns,{"active-tab":o.activeTab,target:o.targetUser,timeline:P(),scroller:u.value,onAddModComment:N},null,8,["active-tab","target","timeline","scroller"])]),_:1},512)],8,Qi)],512)])}}}),Ji=O(Ki,[["__scopeId","data-v-48c304bc"]]),Zi={key:0,class:"seventv-chat-user-badge-list"},el={key:0},tl={key:1},al=Y({__name:"UserTag",props:{user:{},sourceData:{},msgId:{},isMention:{type:Boolean},hideAt:{type:Boolean},hideBadges:{type:Boolean},clickable:{type:Boolean,default:!0},badges:{},badgeData:{}},emits:["open-native-card"],setup(a,{emit:t}){const e=a,r=t,n=ue(),s=$t(n),i=Ye(e.user.id),f=Q("vanity.nametag_paints"),m=Q("vanity.7tv_Badges"),h=Q("chat.user_card"),b=I([]),w=pt(s,"twitchBadgeSets"),u=Q("chat.colored_mentions"),v=I(),g=I(!1),o=I(),$=I(null),P=I([]),E=te(()=>!f.value||!$.value?!1:e.isMention?u.value===2:!0),q=te(()=>!e.isMention||u.value===1);function N(p){if(e.clickable){if(!h.value){r("open-native-card",p);return}g.value=!g.value}}ve(()=>{var p,D;if(e.badges&&w.value&&!b.value.length)for(const[R,F]of Object.entries(e.badges)){const j=R,L=F;for(const d of[((p=e.sourceData)==null?void 0:p.badges.channelsBySet)??w.value.channelsBySet,w.value.globalsBySet]){if(!d)continue;const T=d.get(j);if(!T)continue;const k=T.get(L);if(k){b.value.push({...k,data:(D=e.badgeData)==null?void 0:D[k.setID]});break}}}});const _=Date.now(),C=re([()=>i.paints,()=>i.badges],([p,D])=>{if(e.msgId&&e.user.lastMsgId&&e.msgId!==e.user.lastMsgId&&Date.now()-_>5e3){Le(()=>C());return}$.value=p&&p.size?p.values().next().value:null,P.value=D&&D.size?[...D.values()]:[]},{immediate:!0});return(p,D)=>{var j;const R=pe("cosmetic-paint"),F=pe("tooltip");return l(),c(z,null,[p.user&&p.user.displayName?(l(),c("div",{key:0,ref_key:"tagRef",ref:v,class:"seventv-chat-user",style:$e(q.value?{color:p.user.color}:{})},[!p.hideBadges&&(b.value.length&&((j=w.value)!=null&&j.count)||M(i).badges.size||p.sourceData)?(l(),c("span",Zi,[p.sourceData?(l(),V(Me,{key:p.sourceData.login,badge:p.sourceData,alt:p.sourceData.displayName,type:"picture"},null,8,["badge","alt"])):U("",!0),(l(!0),c(z,null,se(b.value,L=>(l(),V(Me,{key:L.id,badge:L,alt:L.title,type:"twitch",onClick:D[0]||(D[0]=d=>N(d))},null,8,["badge","alt"]))),128)),M(m)?(l(!0),c(z,{key:1},se(P.value,L=>(l(),V(Me,{key:L.id,badge:L,alt:L.data.tooltip,type:"app"},null,8,["badge","alt"]))),128)):U("",!0)])):U("",!0),X((l(),c("span",{class:"seventv-chat-user-username",onClick:D[1]||(D[1]=L=>N(L))},[X((l(),c("span",null,[p.isMention&&!p.hideAt?(l(),c("span",el,"@")):U("",!0),y("span",null,B(p.user.displayName),1),p.user.intl?(l(),c("span",tl," ("+B(p.user.username)+")",1)):U("",!0)])),[[R,E.value?$.value.id:null]])])),[[F,E.value?`Paint: ${$.value.data.name}`:""]])],4)):U("",!0),g.value&&v.value?(l(),V(Be,{key:1,to:"#seventv-float-context"},[x(ma,{class:"seventv-user-card-float",handle:o.value,"initial-anchor":v.value,"initial-middleware":[M(Re)({mainAxis:!0,crossAxis:!0}),M(Nt)()],once:!0},{default:fe(()=>[x(Ji,{target:e.user,onClose:D[2]||(D[2]=L=>g.value=!1),onMountHandle:D[3]||(D[3]=L=>o.value=L)},null,8,["target"])]),_:1},8,["handle","initial-anchor","initial-middleware"])])):U("",!0)],64)}}}),we=O(al,[["__scopeId","data-v-9493ee21"]]);export{Hn as A,Me as B,Ml as I,Ve as U,Zs as W,Ls as _,tn as a,an as b,qe as c,Ca as d,vo as e,Se as f,ae as g,me as h,Te as i,Eo as j,Ge as k,we as l,$l as m,Bn as n,$i as o,Oe as p,G as r,ot as t,$t as u};

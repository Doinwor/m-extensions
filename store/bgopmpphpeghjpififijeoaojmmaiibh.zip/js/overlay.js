(function() {
  const OVERLAY_ID = "tco-ext-element";
  const OVERLAY_TITLEBAR_ID = "tco-ext-element-titlebar";
  const OVERLAY_BUTTON_ID = "tco-ext-element-button";
  const STORAGE_KEY = "tco-ext:settings";

 
  const utils = {
    writeToStorage(key, value) {
      const data = window.localStorage.getItem(STORAGE_KEY);
      const json = JSON.parse(data);
      window.localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ ...(json || {}), [key]: value })
      );
    },

    getFromStorage(key) {
      const data = window.localStorage.getItem(STORAGE_KEY);
      if (data !== null) {
        const json = JSON.parse(data);
        return json[key] || null;
      }
      return null;
    },

    styleToObject(style) {
      const styles = style.split(/; ?/).filter(str => str.length > 0);
      const result = {};
      for (const style of styles) {
        const [key, value] = style.split(/: ?/);
        result[key] = value;
      }
      return result;
    },

    objectToStyle(object) {
      let style = "";
      for (const key in object) {
        style += `${key}: ${object[key]};`;
      }
      return style;
    }
  };

  const intervalIds = [];
  let currentChannel = null;
  let isFullscreen = false;

  // Create a mutation observer so we can watch target elements
  // for attribute changes and detect when the user has gone into
  // fullscreen mode
  const observer = new MutationObserver(mutationCallback);
  function mutationCallback(mutationsList) {
    for (const mutation of mutationsList) {
      const element = mutation.target;
      if (element.id === OVERLAY_ID) {
        const style = element.getAttribute("style");
        if (style !== null && style.length > 0) {
          const object = utils.styleToObject(style);
          utils.writeToStorage("style", object);
        }
      }
    }
  }

  let cleanupWindowEvents = null;
  function buildTitleBar(parent) {
    const element = document.createElement("div");
    element.id = OVERLAY_TITLEBAR_ID;

    // Implement dragging of the chat window
    let isDragging = false;
    let startX, startY, transformX, transformY;

    // RAF function for updating the transform style
    function dragUpdate() {
      if (isDragging) {
        requestAnimationFrame(dragUpdate);
      }
      // Limit to the boundaries
      if (
        transformX <= 0 ||
        transformX + parent.clientWidth >= window.innerWidth ||
        transformY <= 0 ||
        transformY + parent.clientHeight >= window.innerHeight
      ) {
        return;
      }
      parent.style.transform = `translate(${transformX}px, ${transformY}px)`;
    }

    function onMouseDown(event) {
      isDragging = true;

      // Set initial transform values based on the position
      if (transformX === undefined && transformY === undefined) {
        const matches = parent.style.transform.match(/(\d+)px, (\d+)px/);
        transformX = matches ? parseFloat(matches[1]) : 0;
        transformY = matches ? parseFloat(matches[2]) : 0;
      }

      startX = event.pageX - transformX;
      startY = event.pageY - transformY;

      window.addEventListener("mousemove", onMouseMove);
      window.addEventListener("mouseup", onMouseUp);
      requestAnimationFrame(dragUpdate);
    }

    function onMouseUp() {
      isDragging = false;
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
    }

    function onMouseMove(event) {
      transformX = event.pageX - startX;
      transformY = event.pageY - startY;
    }
    element.addEventListener("mousedown", onMouseDown);

    cleanupWindowEvents = function() {
      window.removeEventListener("mouseup", onMouseUp);
      window.removeEventListener("mousemove", onMouseMove);
    };

    return element;
  }

  function buildToggleControl(player, parent) {
    const element = document.createElement("div");
    element.innerHTML = `
      <div id="${OVERLAY_BUTTON_ID}" class="tw-inline-flex tw-relative tw-tooltip-wrapper">
          <button style="width:80px;" class="tw-align-items-center tw-align-middle tw-border-bottom-left-radius-medium tw-border-bottom-right-radius-medium tw-border-top-left-radius-medium tw-border-top-right-radius-medium tw-button-icon tw-button-icon--overlay tw-core-button tw-core-button--overlay tw-inline-flex tw-interactive tw-justify-content-center tw-overflow-hidden tw-relative" aria-label="Twitch Chat Overlay">
          Toggle Chat
          </button>
        <div class="tw-tooltip tw-tooltip--align-right tw-tooltip--up" role="tooltip">Twitch Chat Overlay</div>
      </div>
    `;
    function onClick() {
      // Will only be undefined on first run, where settings aren't saved
      const state = parent.style.visibility || "visible";
      if (state === "visible") {
        parent.style.visibility = "hidden";
      } else {
        parent.style.visibility = "visible";
      }
    }
    element.querySelector("button").addEventListener("click", onClick);

    const target = player.querySelector(
      ".player-controls__right-control-group"
    );
    if (target) {
      target.prepend(element);
    }
  }

 

  // Load up the current Twitch chat as an overlay on the stream
  function createChatOverlay(target) {
    const parent = document.createElement("div");
    parent.id = OVERLAY_ID;

    // Set the initial style to the last session
    const style = utils.getFromStorage("style");
    if (style !== null) {
      parent.setAttribute("style", utils.objectToStyle(style));
    }

    // Toggle control
    buildToggleControl(target, parent);

    const squadElement =
      target.parentNode &&
      target.parentNode.parentNode &&
      target.parentNode.parentNode.parentNode;
    if (
      squadElement &&
      (squadElement.classList.contains("multi-stream-player-layout__player") ||
        squadElement.classList.contains(
          "multi-stream-player-layout__player-primary"
        ))
    ) {
      currentChannel = squadElement.dataset["aChannel"];
    }

    // Build the embedded element
    const child = document.createElement("iframe");
    child.src = `https://www.twitch.tv/popout/${currentChannel}/chat?darkpopout`;

    function onLoad() {
     
      onLeave();
    }

    function onEnter() {
      if (!child.contentDocument) {
        return;
      }
      child.contentDocument.querySelector(".chat-input").style =
        "display: block !important";
    }

    function onLeave() {
      if (!child.contentDocument) {
        return;
      }
      child.contentDocument.querySelector(".chat-input").style =
        "display: none !important";
    }

    child.addEventListener("load", onLoad);
    parent.addEventListener("mouseenter", onEnter);
    parent.addEventListener("mouseleave", onLeave);


    observer.observe(parent, { attributes: true });

    parent.appendChild(buildTitleBar(parent));
    parent.appendChild(child);
    target.appendChild(parent);
  }

  // Get access to the React instance on Twitch
  let cleanupHistoryListener = null;
  function hookIntoReact() {
    // Watch for navigation changes within the React app
    function reactNavigationHook({ history }) {
      let lastPathName = history.location.pathname;
      cleanupHistoryListener = history.listen(function(location) {
        if (location.pathname !== lastPathName) {
          lastPathName = location.pathname;
          cleanup();
          start();
        }
      });
    }

    // Find a property within the React component tree
    function findReactProp(node, props, func) {
      for (let i = 0; i < props.length; i++) {
        const prop = props[i];
        if (
          node.stateNode &&
          node.stateNode.props &&
          node.stateNode.props[prop]
        ) {
          return func(node.stateNode.props);
        } else if (node.child) {
          let child = node.child;
          while (child) {
            findReactProp(child, [prop], func);
            child = child.sibling;
          }
        }
      }
    }

    // Find the react instance of a element
    function findReactInstance(elements, target, func) {
      const timer = setInterval(function() {
        elements.forEach(element => {
          const reactRoot = document.querySelector(element);
          if (reactRoot) {
            let reactInstance = null;
            for (const key of Object.keys(reactRoot)) {
              if (key.startsWith(target)) {
                reactInstance = reactRoot[key];
                break;
              }
            }
            if (reactInstance) {
              func(reactInstance);
              clearInterval(timer);
            }
          }
        });
      }, 500);
      intervalIds.push(timer);
    }

    // Find the root instance and hook into the router history
    findReactInstance(["#root"], "_reactRootContainer", function(instance) {
      if (instance._internalRoot && instance._internalRoot.current) {
        findReactProp(
          instance._internalRoot.current,
          ["history"],
          reactNavigationHook
        );
      }
    });

    // Find the instance related to the video player to find the current stream
    const intervalId = setInterval(function() {
      findReactInstance(
        [".video-player__default-player"],
        "__reactInternalInstance$",
        function(instance) {
          findReactProp(instance, ["channelLogin"], function(object) {
            if (object.channelLogin && "isFullscreen" in object) {
              currentChannel = object.channelLogin;
              if (object.isFullscreen && !isFullscreen) {
                isFullscreen = true;
                const fsElement = document.querySelector(
                  ".video-player__overlay"
                );
                createChatOverlay(fsElement);
              } else if (!object.isFullscreen && isFullscreen) {
                isFullscreen = true;
               // destroyChatOverlay();
              }
            }
          });
        }
      );
    }, 1000);
    intervalIds.push(intervalId);
  }

  function start() {
   // window.addEventListener("beforeunload", cleanup);
    hookIntoReact();
  }

  function cleanup() {
   // window.removeEventListener("beforeunload", cleanup);
    //destroyChatOverlay();
    observer.disconnect();
    for (const id of intervalIds) {
      clearInterval(id);
    }
    if (cleanupHistoryListener !== null) {
      cleanupHistoryListener();
    }
  }

  // Convert the legacy storage format
  const version = utils.getFromStorage("version");
  if (version === null) {
    const style = utils.getFromStorage("style");
    if (style !== undefined && typeof style === "string") {
      const object = utils.styleToObject(style);
      utils.writeToStorage("style", object);
      utils.writeToStorage("version", 1);
    }
  }

 
  start();
  console.log("Twitch Chat Overlay Extension Loaded");
})();

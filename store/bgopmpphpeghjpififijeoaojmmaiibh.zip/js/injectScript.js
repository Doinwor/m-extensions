var element = document.createElement("script");
element.src = chrome.runtime.getURL("js/overlay.js");
document.body.appendChild(element);
